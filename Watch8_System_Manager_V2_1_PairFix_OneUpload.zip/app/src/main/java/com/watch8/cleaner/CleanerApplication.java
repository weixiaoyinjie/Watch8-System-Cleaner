package com.watch8.cleaner;

import android.app.Application;
import java.security.Security;
import org.conscrypt.Conscrypt;

public class CleanerApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        CrashDiagnostics.installHandler(this);
        try {
            // ADB wireless pairing requires TLS 1.3. Do not take down the whole
            // UI if a device has a broken or missing Conscrypt native backend.
            Security.insertProviderAt(Conscrypt.newProvider(), 1);
        } catch (Throwable error) {
            CrashDiagnostics.failed(this, "加载 TLS 加密组件", error);
        }
    }
}
