package com.watch8.cleaner;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.Arrays;

/** Conservative rules: these are heuristics, not proof that a package is safe. */
public final class SafetyPolicy {
    public enum Level { PROTECTED, CAUTION, USER_APP }
    private static final Set<String> EXACT = new HashSet<>(Arrays.asList(
        "android", "com.android.systemui", "com.android.settings", "com.android.phone",
        "com.android.bluetooth", "com.android.shell", "com.android.permissioncontroller",
        "com.android.packageinstaller", "com.google.android.packageinstaller",
        "com.google.android.permissioncontroller", "com.android.vending",
        "com.google.android.gms", "com.google.android.gsf",
        "com.google.android.wearable.app", "com.samsung.android.app.watchmanager",
        "com.samsung.android.oneui.home", "com.sec.android.app.launcher",
        "com.android.inputdevices", "com.android.keychain", "com.android.location.fused"
    ));
    private static final String[] PREFIX = {
        "com.android.providers.", "com.android.networkstack", "com.android.server.",
        "com.android.wifi.", "com.android.telephony.", "com.android.connectivity.",
        "com.google.android.networkstack", "com.google.android.wearable.",
        "com.google.android.clockwork.", "com.samsung.android.wearable.",
        "com.samsung.android.knox.", "com.samsung.android.security.",
        "com.samsung.android.connectivity.", "com.samsung.android.systemui.",
        "com.samsung.android.hardware.", "com.sec.android.provider."
    };
    private static final Map<String, String> NAMES = new HashMap<>();
    static {
        NAMES.put("com.google.android.apps.maps", "Google 地图");
        NAMES.put("com.google.android.youtube", "YouTube");
        NAMES.put("com.google.android.apps.youtube.music", "YouTube Music");
        NAMES.put("com.google.android.apps.wellbeing", "数字健康");
        NAMES.put("com.google.android.apps.assistant", "Google 助理");
        NAMES.put("com.google.android.googlequicksearchbox", "Google 搜索 / 助理");
        NAMES.put("com.google.android.gm", "Gmail");
        NAMES.put("com.google.android.apps.messaging", "Google 信息");
        NAMES.put("com.google.android.apps.walletnfcrel", "Google 钱包");
        NAMES.put("com.google.android.wearable.app", "Wear OS 核心");
        NAMES.put("com.google.android.gms", "Google Play 服务");
        NAMES.put("com.android.vending", "Google Play 商店");
        NAMES.put("com.android.settings", "系统设置");
        NAMES.put("com.android.systemui", "系统界面");
        NAMES.put("com.android.bluetooth", "蓝牙服务");
        NAMES.put("com.samsung.android.oneui.home", "One UI 桌面");
        NAMES.put("com.samsung.android.app.watchmanager", "Samsung 手表管理");
        NAMES.put("com.samsung.android.shealth", "三星健康");
        NAMES.put("com.samsung.android.app.healthmonitor", "三星健康监测");
        NAMES.put("com.samsung.android.app.reminder", "三星提醒");
        NAMES.put("com.samsung.android.bixby.agent", "Bixby");
        NAMES.put("com.samsung.android.app.notes", "三星笔记");
        NAMES.put("com.samsung.android.messaging", "三星信息");
        NAMES.put("com.samsung.android.calendar", "三星日历");
        NAMES.put("com.samsung.android.weather", "三星天气");
        NAMES.put("com.sec.android.app.clockpackage", "三星时钟");
        NAMES.put("com.samsung.android.wearable.watchface", "三星表盘服务");
    }
    public static Level classify(String pkg, boolean system) {
        if (EXACT.contains(pkg)) return Level.PROTECTED;
        for (String prefix : PREFIX) if (pkg.startsWith(prefix)) return Level.PROTECTED;
        // Anything unrecognized is CAUTION, never marked "safe" automatically.
        return system ? Level.CAUTION : Level.USER_APP;
    }
    public static String labelFor(String pkg) {
        String known = NAMES.get(pkg);
        if (known != null) return known;
        int end = pkg.lastIndexOf('.');
        String tail = end >= 0 ? pkg.substring(end + 1) : pkg;
        if (tail.equals("app") && end > 0) {
            int second = pkg.lastIndexOf('.', end - 1);
            if (second >= 0) tail = pkg.substring(second + 1, end);
        }
        return tail.replace('_', ' ');
    }
    public static String status(Level level) {
        if (level == Level.PROTECTED) return "核心保护";
        if (level == Level.CAUTION) return "需谨慎";
        return "用户安装";
    }
    public static boolean validPackageName(String pkg) {
        return pkg != null && pkg.matches("[a-zA-Z][a-zA-Z0-9_]*(\\.[a-zA-Z0-9_]+)+");
    }
    private SafetyPolicy() { }
}
