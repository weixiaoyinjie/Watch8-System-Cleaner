package com.watch8.cleaner;

import android.content.Context;
import android.os.Build;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.math.BigInteger;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Date;
import io.github.muntashirakon.adb.AbsAdbConnectionManager;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.X509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;

/** Persist a single RSA-2048 ADB identity so that users do not re-pair each launch. */
public final class AdbIdentity extends AbsAdbConnectionManager {
    private static AdbIdentity singleton;
    private final PrivateKey privateKey;
    private final Certificate certificate;

    public static synchronized AdbIdentity get(Context context) throws Exception {
        if (singleton == null) singleton = new AdbIdentity(context.getApplicationContext());
        return singleton;
    }

    private AdbIdentity(Context context) throws Exception {
        setApi(Build.VERSION.SDK_INT);
        File keyFile = new File(context.getFilesDir(), "watch8_adb_private.pk8");
        File certFile = new File(context.getFilesDir(), "watch8_adb_cert.der");
        if (keyFile.isFile() && certFile.isFile()) {
            byte[] key = new byte[(int) keyFile.length()];
            try (FileInputStream input = new FileInputStream(keyFile)) {
                int pos = 0, n;
                while (pos < key.length && (n = input.read(key, pos, key.length - pos)) > 0) pos += n;
                if (pos != key.length) throw new java.io.IOException("Incomplete key");
            }
            privateKey = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(key));
            try (FileInputStream input = new FileInputStream(certFile)) {
                certificate = CertificateFactory.getInstance("X.509").generateCertificate(input);
            }
        } else {
            KeyPairGenerator generator = KeyPairGenerator.getInstance("RSA");
            SecureRandom random = new SecureRandom();
            generator.initialize(2048, random);
            KeyPair pair = generator.generateKeyPair();
            privateKey = pair.getPrivate();
            Date start = new Date(System.currentTimeMillis() - 86_400_000L);
            Date end = new Date(System.currentTimeMillis() + 10L * 365 * 86_400_000L);
            X500Name dn = new X500Name("CN=Watch8 System Cleaner");
            X509v3CertificateBuilder builder = new JcaX509v3CertificateBuilder(
                    dn, new BigInteger(120, random).abs(), start, end, dn, pair.getPublic());
            ContentSigner signer = new JcaContentSignerBuilder("SHA256withRSA").build(privateKey);
            certificate = new JcaX509CertificateConverter().getCertificate(builder.build(signer));
            try (FileOutputStream out = new FileOutputStream(keyFile)) { out.write(privateKey.getEncoded()); }
            try (FileOutputStream out = new FileOutputStream(certFile)) { out.write(certificate.getEncoded()); }
        }
    }

    @Override protected PrivateKey getPrivateKey() { return privateKey; }
    @Override protected Certificate getCertificate() { return certificate; }
    @Override protected String getDeviceName() { return "Watch8-Cleaner"; }
}
