package com.watch8.cleaner;

/** State reported by PackageManager on the remote watch user 0. */
public final class PackageInfoItem {
    public final String name;
    public final boolean system;
    public boolean installed = true;
    public boolean disabled;
    public String label;
    public SafetyPolicy.Level level;

    public PackageInfoItem(String name, boolean system) {
        this.name = name;
        this.system = system;
        this.label = SafetyPolicy.labelFor(name);
        this.level = SafetyPolicy.classify(name, system);
    }
}
