package com.watch8.cleaner;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import io.github.muntashirakon.adb.AdbStream;

/** ADB client executes commands on the WATCH, not the phone. Do not use on UI thread. */
public final class WatchAdb {
    private final Context context;
    private final ScheduledExecutorService watchdog = Executors.newSingleThreadScheduledExecutor();

    public WatchAdb(Context context) { this.context = context.getApplicationContext(); }

    private AdbIdentity identity() throws Exception { return AdbIdentity.get(context); }

    public boolean pair(String ip, int pairingPort, String sixDigitCode) throws Exception {
        return identity().pair(ip, pairingPort, sixDigitCode);
    }
    public void connect(String ip, int connectionPort) throws Exception {
        if (identity().isConnected()) identity().disconnect();
        if (!identity().connect(ip, connectionPort) && !identity().isConnected())
            throw new IllegalStateException("ADB 连接失败，请检查手表的连接端口和 Wi-Fi");
    }
    public void disconnect() throws Exception { identity().disconnect(); }
    public boolean isConnected() {
        try { return identity().isConnected(); } catch (Exception e) { return false; }
    }

    public synchronized CommandResult run(String command) throws Exception {
        return run(command, 22);
    }

    public synchronized CommandResult run(String command, int timeoutSeconds) throws Exception {
        if (!isConnected()) throw new IllegalStateException("手表尚未连接。请检查无线调试端口。");
        // A random marker separates shell exit status from all command output.
        final String sentinel = "__W8_EXIT_" + UUID.randomUUID().toString().replace("-", "") + "__";
        final String wrapped = "(" + command + ") 2>&1; echo " + sentinel + "$?";
        final AdbStream stream = identity().openStream("shell:" + wrapped);
        ScheduledFuture<?> timeout = watchdog.schedule(() -> {
            try { stream.close(); } catch (Exception ignored) { }
        }, timeoutSeconds, TimeUnit.SECONDS);
        try {
            ByteArrayOutputStream data = new ByteArrayOutputStream(8192);
            byte[] buf = new byte[8192];
            InputStream in = stream.openInputStream();
            String text = "";
            boolean complete = false;
            while (true) {
                int size = in.read(buf);
                if (size == -1) break;
                if (size == 0) continue;
                data.write(buf, 0, size);
                if (data.size() > 3_000_000) throw new IllegalStateException("设备输出超过 3MB，已终止读取");
                text = data.toString("UTF-8");
                // Wait for end of the exit code; ADB packets can split strings.
                if (Pattern.compile(Pattern.quote(sentinel) + "[0-9]+(?:\\r?\\n|$)").matcher(text).find()) {
                    complete = true;
                    break;
                }
            }
            if (!complete) throw new IllegalStateException("指令未完成或连接已超时；请重新连接手表。");
            Matcher match = Pattern.compile(Pattern.quote(sentinel) + "(\\d+)").matcher(text);
            if (!match.find()) throw new IllegalStateException("无法获得指令执行结果");
            int code = Integer.parseInt(match.group(1));
            return new CommandResult(code, text.substring(0, match.start()).trim());
        } finally {
            timeout.cancel(false);
            try { stream.close(); } catch (Exception ignored) { }
        }
    }

    /**
     * Push a single APK using the real ADB sync: SEND/DATA/DONE protocol.
     * Uses constant-size buffers; never loads the complete APK in RAM.
     * Only an app-generated, fixed /data/local/tmp path is permitted.
     */
    public synchronized void pushApk(File apk, String remotePath, ProgressListener progress) throws Exception {
        if (!isConnected()) throw new IllegalStateException("请先连接手表");
        if (!remotePath.matches("/data/local/tmp/w8_inst_[a-f0-9]{32}\\.apk"))
            throw new IllegalArgumentException("无效的临时文件路径");
        if (!apk.isFile() || apk.length() < 1024) throw new IllegalArgumentException("APK 文件无效或为空");
        final AdbStream stream = identity().openStream("sync:");
        ScheduledFuture<?> timeout = watchdog.schedule(() -> {
            try { stream.close(); } catch (Exception ignored) { }
        }, 300, TimeUnit.SECONDS);
        try {
            OutputStream out = stream.openOutputStream();
            InputStream in = stream.openInputStream();
            byte[] pathMode = (remotePath + ",33188").getBytes(StandardCharsets.UTF_8); // 0100644
            sendSyncHeader(out, "SEND", pathMode.length);
            out.write(pathMode);
            byte[] buf = new byte[64 * 1024];
            long sent = 0, total = apk.length();
            int lastPercent = -1;
            try (FileInputStream fileIn = new FileInputStream(apk)) {
                int n;
                while ((n = fileIn.read(buf)) != -1) {
                    if (n == 0) continue;
                    sendSyncHeader(out, "DATA", n);
                    out.write(buf, 0, n);
                    sent += n;
                    int percent = (int)(sent * 100 / total);
                    if (percent != lastPercent && progress != null) {
                        lastPercent = percent;
                        progress.onProgress(sent, total);
                    }
                }
            }
            sendSyncHeader(out, "DONE", (int)(System.currentTimeMillis() / 1000L));
            out.flush();
            byte[] ack = new byte[8];
            readExactly(in, ack);
            String id = new String(ack, 0, 4, StandardCharsets.US_ASCII);
            int len = ByteBuffer.wrap(ack, 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
            if ("OKAY".equals(id)) return;
            if ("FAIL".equals(id)) {
                if (len < 0 || len > 8192) throw new IllegalStateException("同步失败，错误长度无效");
                byte[] err = new byte[len];
                readExactly(in, err);
                throw new IllegalStateException("传输失败：" + new String(err, StandardCharsets.UTF_8));
            }
            throw new IllegalStateException("ADB 同步未确认完成：" + id);
        } finally {
            timeout.cancel(false);
            try { stream.close(); } catch (Exception ignored) { }
        }
    }

    private static void sendSyncHeader(OutputStream out, String cmd, int size) throws Exception {
        if (cmd.length() != 4) throw new IllegalArgumentException("ADB sync command is not 4 bytes");
        byte[] header = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
            .put(cmd.getBytes(StandardCharsets.US_ASCII)).putInt(size).array();
        out.write(header);
    }

    private static void readExactly(InputStream in, byte[] buffer) throws Exception {
        int offset = 0;
        while (offset < buffer.length) {
            int n = in.read(buffer, offset, buffer.length - offset);
            if (n < 0) throw new java.io.EOFException("ADB sync response incomplete");
            if (n > 0) offset += n;
        }
    }

    public interface ProgressListener { void onProgress(long bytesSent, long totalBytes); }

    public void shutdown() { watchdog.shutdownNow(); }

    public static final class CommandResult {
        public final int exitCode;
        public final String output;
        CommandResult(int exitCode, String output) { this.exitCode = exitCode; this.output = output; }
        public boolean ok() { return exitCode == 0; }
        public void requireSuccess() {
            if (!ok()) throw new IllegalStateException(output.isEmpty() ? "指令执行失败，退出码：" + exitCode : output);
        }
    }
}
