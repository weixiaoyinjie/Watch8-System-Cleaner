package com.watch8.cleaner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Queries the WATCH via ADB. Does not scan local phone apps. */
public final class PackageScanner {
    public static final class ScanResult {
        public final List<PackageInfoItem> items;
        public final String deviceModel;
        public final boolean isWatch;
        ScanResult(List<PackageInfoItem> items, String deviceModel, boolean isWatch) {
            this.items = items; this.deviceModel = deviceModel; this.isWatch = isWatch;
        }
    }
    private static Set<String> packages(String output) {
        Set<String> set = new HashSet<>();
        for (String line : output.split("\\r?\\n")) {
            if (!line.startsWith("package:")) continue;
            String pkg = line.substring(8).trim();
            if (SafetyPolicy.validPackageName(pkg)) set.add(pkg);
        }
        return set;
    }

    public static ScanResult scan(WatchAdb adb) throws Exception {
        String model = adb.run("getprop ro.product.model").output.trim();
        String characteristics = adb.run("getprop ro.build.characteristics").output;
        String features = adb.run("pm list features").output;
        boolean watch = characteristics.contains("watch") || features.contains("android.hardware.type.watch");

        WatchAdb.CommandResult systemResult = adb.run("pm list packages -s --user 0");
        systemResult.requireSuccess();
        WatchAdb.CommandResult userResult = adb.run("pm list packages -3 --user 0");
        userResult.requireSuccess();
        Set<String> system = packages(systemResult.output);
        Set<String> user = packages(userResult.output);
        Set<String> disabled = new HashSet<>();
        try { disabled = packages(adb.run("pm list packages -d --user 0").output); }
        catch (Exception ignored) { }
        Map<String, PackageInfoItem> all = new HashMap<>();
        for (String pkg : system) all.put(pkg, new PackageInfoItem(pkg, true));
        for (String pkg : user) all.put(pkg, new PackageInfoItem(pkg, false));
        for (String pkg : disabled) if (all.containsKey(pkg)) all.get(pkg).disabled = true;
        List<PackageInfoItem> items = new ArrayList<>(all.values());
        Collections.sort(items, (a, b) -> {
            int group = Boolean.compare(b.system, a.system);
            return group != 0 ? group : a.name.compareToIgnoreCase(b.name);
        });
        return new ScanResult(items, model, watch);
    }
    private PackageScanner() { }
}
