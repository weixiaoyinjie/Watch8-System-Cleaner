package com.watch8.cleaner;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Iterator;

/** Device-local recovery history; no uploads, analytics or cloud access. */
public final class HistoryStore {
    private final SharedPreferences preferences;
    public HistoryStore(Context ctx) {
        preferences = ctx.getSharedPreferences("watch8_recovery", Context.MODE_PRIVATE);
    }
    public synchronized void record(String pkg, String label, String operation) {
        try {
            JSONObject all = new JSONObject(preferences.getString("records", "{}"));
            JSONObject row = new JSONObject();
            row.put("label", label);
            row.put("operation", operation);
            row.put("date", System.currentTimeMillis());
            all.put(pkg, row);
            preferences.edit().putString("records", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    public synchronized void remove(String pkg) {
        try {
            JSONObject all = new JSONObject(preferences.getString("records", "{}"));
            all.remove(pkg);
            preferences.edit().putString("records", all.toString()).apply();
        } catch (Exception ignored) { }
    }
    public synchronized Map<String, Entry> entries() {
        Map<String, Entry> results = new LinkedHashMap<>();
        try {
            JSONObject all = new JSONObject(preferences.getString("records", "{}"));
            Iterator<String> it = all.keys();
            while (it.hasNext()) {
                String pkg = it.next();
                JSONObject e = all.optJSONObject(pkg);
                if (e != null) results.put(pkg, new Entry(pkg,
                    e.optString("label", pkg), e.optString("operation", "remove")));
            }
        } catch (Exception ignored) { }
        return results;
    }
    public static final class Entry {
        public final String pkg, label, operation;
        Entry(String pkg, String label, String operation) {
            this.pkg = pkg; this.label = label; this.operation = operation;
        }
    }
}
