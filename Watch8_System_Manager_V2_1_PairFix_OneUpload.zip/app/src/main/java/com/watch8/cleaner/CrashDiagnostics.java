package com.watch8.cleaner;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Private on-device error log. Never store the 6-digit pairing code. */
public final class CrashDiagnostics {
    private static final String PREFS = "watch8_diagnostics_v3";
    private static final int MAX_TRACE_CHARS = 9000;
    private CrashDiagnostics() { }

    private static SharedPreferences prefs(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static void start(Context c, String step) {
        prefs(c).edit().putString("step", step).putLong("started", System.currentTimeMillis())
            .putString("last_problem", "").commit();
    }

    public static void completed(Context c) {
        prefs(c).edit().putString("step", "idle").putLong("started", 0L).apply();
    }

    public static void failed(Context c, String step, Throwable error) {
        if (error == null) return;
        StringWriter sw = new StringWriter();
        error.printStackTrace(new PrintWriter(sw));
        String trace = sw.toString();
        if (trace.length() > MAX_TRACE_CHARS) trace = trace.substring(0, MAX_TRACE_CHARS);
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(new Date());
        prefs(c).edit().putString("last_problem", timestamp + " / " + step + "\n" + trace)
            .putString("step", "idle").putLong("started", 0L).commit();
        Log.e("Watch8Manager", "Failed at: " + step, error);
    }

    public static void installHandler(Context context) {
        final Context app = context.getApplicationContext();
        final Thread.UncaughtExceptionHandler existing = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((thread, error) -> {
            try { failed(app, "线程 " + thread.getName(), error); }
            catch (Throwable ignored) { /* Preserve original crash handler. */ }
            if (existing != null) existing.uncaughtException(thread, error);
        });
    }

    public static String previousInterruptedStep(Context c) {
        String step = prefs(c).getString("step", "idle");
        if ("idle".equals(step)) return "";
        // If the pairing operation was interrupted, explain it instead of claiming success.
        return step;
    }

    public static String report(Context c) {
        SharedPreferences p = prefs(c);
        String step = p.getString("step", "idle");
        long started = p.getLong("started", 0L);
        StringBuilder sb = new StringBuilder();
        sb.append("Watch8 应用管理器 V2.1.1 · 本地诊断\n")
            .append("手机 Android ").append(Build.VERSION.RELEASE)
            .append(" / SDK ").append(Build.VERSION.SDK_INT)
            .append(" / ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
            .append("上次步骤: ").append(step).append('\n');
        String lastProblem = p.getString("last_problem", "");
        if (!lastProblem.isEmpty()) sb.append("上次错误:\n").append(lastProblem).append('\n');
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                ActivityManager am = (ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                if (am != null) {
                    List<ApplicationExitInfo> exits = am.getHistoricalProcessExitReasons(c.getPackageName(), 0, 4);
                    if (exits != null) {
                        int count = 0;
                        for (ApplicationExitInfo exit : exits) {
                            int reason = exit.getReason();
                            if (reason == ApplicationExitInfo.REASON_CRASH ||
                                reason == ApplicationExitInfo.REASON_CRASH_NATIVE ||
                                (started > 0 && exit.getTimestamp() >= started)) {
                                sb.append("进程退出: reason=").append(reason)
                                    .append(" / time=").append(exit.getTimestamp())
                                    .append(" / ").append(exit.getDescription()).append('\n');
                                if (++count >= 2) break;
                            }
                        }
                    }
                }
            } catch (Exception ignored) { }
        }
        sb.append("配对码未保存；不要在反馈中附上配对码。\n");
        return sb.toString();
    }
}
