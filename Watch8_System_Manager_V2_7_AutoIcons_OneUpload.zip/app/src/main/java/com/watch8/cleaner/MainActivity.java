package com.watch8.cleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ClipDescription;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.nsd.NsdManager;
import android.net.nsd.NsdServiceInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ImageView;
import android.graphics.drawable.Drawable;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.UUID;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;

/** A standalone PHONE app. Nothing is installed on the Galaxy Watch. */
public final class MainActivity extends Activity {
    private static final int APK_PICK_REQUEST = 3071;
    private static final long MAX_APK_BYTES = 200L * 1024 * 1024;
    private static final int BG = Color.rgb(246, 249, 249);
    private static final int TEXT = Color.rgb(29, 43, 45);
    private static final int MUTED = Color.rgb(91, 107, 110);
    private static final int GREEN = Color.rgb(23, 109, 99);
    private static final int RED = Color.rgb(166, 47, 47);
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final List<PackageInfoItem> allItems = new ArrayList<>();
    private final List<DisplayRow> shown = new ArrayList<>();
    private final Set<String> selected = new HashSet<>();
    // A failed icon must not be downloaded again during every scan/session action.
    // A user can still retry a specific icon from that app's details.
    private final Set<String> iconFailures = java.util.Collections.synchronizedSet(new HashSet<>());
    private static final int INITIAL_ICON_BATCH = 6;
    private static final int MANUAL_ICON_BATCH = 12;
    private final List<Endpoint> discovered = new ArrayList<>();
    private WatchAdb adb;
    private HistoryStore history;
    private SharedPreferences settings;
    private EditText ip, pairingPort, pairingCode, connectPort, search;
    private TextView status, counter, device;
    private LinearLayout connectionPanel;
    private Button pairButton, connectButton, scanButton, bulkButton, installButton, settingToggle, iconButton;
    private Button desktopTab, systemTab, allTab, historyTab;
    private ListView list;
    private ListAdapter adapter;
    private volatile boolean connected = false;
    private volatile boolean confirmedWatch = false;
    private boolean busy = false;
    private int filter = 0; // 0 = watch launcher; 1 = system; 2 = all; 3 = recovery history
    private boolean launcherKnown;
    private NsdManager nsd;
    private NsdManager.DiscoveryListener discoverPair, discoverConnect;
    private boolean discovering;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        adb = new WatchAdb(this);
        history = new HistoryStore(this);
        settings = getSharedPreferences("watch8_settings", MODE_PRIVATE);
        nsd = (NsdManager) getSystemService(NSD_SERVICE);
        buildUi();
        String interrupted = CrashDiagnostics.previousInterruptedStep(this);
        if (!interrupted.isEmpty()) {
            setStatus("检测到上次「" + interrupted + "」操作中断。请点击【复制诊断】，本版不会静默报告配对成功。", true);
            connectionPanel.setVisibility(View.VISIBLE);
            settingToggle.setText("连接设置 ▲");
        } else {
            setStatus("尚未连接手表。首次请先配对，再连接。", false);
        }
    }

    private int dp(float px) { return (int) (px * getResources().getDisplayMetrics().density + .5f); }
    private GradientDrawable shape(int bg, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(bg);
        d.setCornerRadius(dp(radius));
        if (stroke != 0) d.setStroke(dp(1), stroke);
        return d;
    }
    private TextView text(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }
    private Button button(String title, boolean primary) {
        Button b = new Button(this);
        b.setText(title);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setTextColor(primary ? Color.WHITE : GREEN);
        b.setBackground(shape(primary ? GREEN : Color.WHITE, 11, primary ? 0 : 0xFFD3E2DF));
        b.setMinimumHeight(dp(42));
        return b;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
    private LinearLayout.LayoutParams margin(int w, int h, int top, int right) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(w, h);
        lp.topMargin = dp(top);
        lp.rightMargin = dp(right);
        return lp;
    }
    private EditText field(String hint, String value, boolean numbers) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setTextSize(14);
        e.setTextColor(TEXT);
        e.setHint(hint);
        e.setHintTextColor(0xFF829596);
        e.setInputType(numbers ? InputType.TYPE_CLASS_NUMBER : InputType.TYPE_CLASS_TEXT |
            InputType.TYPE_TEXT_VARIATION_URI);
        e.setPadding(dp(10), dp(10), dp(10), dp(10));
        e.setBackground(shape(Color.WHITE, 9, 0xFFD3E2DF));
        e.setText(value);
        return e;
    }
    private void buildUi() {
        LinearLayout root = vertical();
        root.setPadding(dp(14), dp(12), dp(14), dp(9));
        root.setBackgroundColor(BG);
        setContentView(root);
        TextView title = text("Watch8 应用管理器", 23, TEXT, true);
        root.addView(title);
        TextView subtitle = text("V2.7 自动图标版 · 系统卸载 + 第三方 APK 安装", 12, MUTED, false);
        root.addView(subtitle, margin(-1, -2, 3, 0));

        LinearLayout top = horizontal();
        settingToggle = button("连接设置 ▲", false);
        top.addView(settingToggle, new LinearLayout.LayoutParams(0, dp(41), 1));
        Button detect = button("自动找手表", false);
        top.addView(detect, margin(0, dp(41), 0, 0));
        LinearLayout.LayoutParams dlp = (LinearLayout.LayoutParams) detect.getLayoutParams();
        dlp.width = 0; dlp.weight = 1; dlp.leftMargin = dp(9);
        root.addView(top, margin(-1, dp(41), 13, 0));
        settingToggle.setOnClickListener(v -> {
            boolean show = connectionPanel.getVisibility() != View.VISIBLE;
            connectionPanel.setVisibility(show ? View.VISIBLE : View.GONE);
            settingToggle.setText(show ? "连接设置 ▲" : "连接设置 ▼");
        });
        detect.setOnClickListener(v -> autoDiscover());

        connectionPanel = vertical();
        connectionPanel.setBackground(shape(Color.WHITE, 12, 0xFFE0E8E7));
        connectionPanel.setPadding(dp(11), dp(9), dp(11), dp(11));
        root.addView(connectionPanel, margin(-1, -2, 9, 0));
        ip = field("手表 IP，例如 192.168.1.50", settings.getString("ip", ""), false);
        connectionPanel.addView(text("① 手表 Wi-Fi 地址", 12, MUTED, true));
        connectionPanel.addView(ip, margin(-1, dp(39), 4, 0));
        LinearLayout pairing = horizontal();
        pairingPort = field("配对端口", settings.getString("pair_port", ""), true);
        pairingCode = field("6 位配对码", "", true);
        pairing.addView(pairingPort, new LinearLayout.LayoutParams(0, dp(39), 1));
        LinearLayout.LayoutParams codeLp = new LinearLayout.LayoutParams(0, dp(39), 1);
        codeLp.leftMargin = dp(8);
        pairing.addView(pairingCode, codeLp);
        connectionPanel.addView(text("② 配对页面的端口 + 6 位验证码（只需首次配对）", 12, MUTED, false), margin(-1, -2, 8, 0));
        connectionPanel.addView(pairing, margin(-1, dp(39), 4, 0));
        LinearLayout pairActions = horizontal();
        pairButton = button("进行配对", false);
        pairActions.addView(pairButton, new LinearLayout.LayoutParams(0, dp(38), 2));
        pairButton.setOnClickListener(v -> pairDevice());
        Button diagnosticButton = button("复制诊断", false);
        LinearLayout.LayoutParams diagnosticLp = new LinearLayout.LayoutParams(0, dp(38), 1);
        diagnosticLp.leftMargin = dp(8);
        pairActions.addView(diagnosticButton, diagnosticLp);
        connectionPanel.addView(pairActions, margin(-1, dp(38), 7, 0));
        diagnosticButton.setOnClickListener(v -> {
            String report = CrashDiagnostics.report(this);
            ClipboardManager clip = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            if (clip != null) clip.setPrimaryClip(ClipData.newPlainText("Watch8 诊断", report));
            new AlertDialog.Builder(this).setTitle("已复制诊断信息")
                .setMessage(report.length() > 2200 ? report.substring(0, 2200) + "…" : report)
                .setPositiveButton("确定", null).show();
        });
        LinearLayout session = horizontal();
        connectPort = field("连接端口（不是配对端口）", settings.getString("connect_port", ""), true);
        session.addView(connectPort, new LinearLayout.LayoutParams(0, dp(40), 1));
        connectButton = button("连接手表", true);
        LinearLayout.LayoutParams connectLp = margin(dp(104), dp(40), 0, 0);
        connectLp.leftMargin = dp(8);
        session.addView(connectButton, connectLp);
        connectionPanel.addView(text("③ 无线调试主页的 IP:端口", 12, MUTED, false), margin(-1, -2, 9, 0));
        connectionPanel.addView(session, margin(-1, dp(40), 4, 0));
        connectButton.setOnClickListener(v -> connectDevice());
        TextView instructions = text("手表：设置 → 开发者选项 → 无线调试。配对端口与连接端口不同；手机和手表需在同一 Wi-Fi。", 11, MUTED, false);
        connectionPanel.addView(instructions, margin(-1, -2, 8, 0));
        if (!settings.getString("ip", "").isEmpty()) {
            connectionPanel.setVisibility(View.GONE);
            settingToggle.setText("连接设置 ▼");
        }

        status = text("", 12, MUTED, false);
        status.setPadding(dp(10), dp(9), dp(10), dp(9));
        status.setBackground(shape(0xFFE8F1F0, 9, 0));
        root.addView(status, margin(-1, -2, 8, 0));
        device = text("", 11, MUTED, false);
        root.addView(device, margin(-1, -2, 5, 0));

        LinearLayout actions = horizontal();
        scanButton = button("扫描手表 App", true);
        actions.addView(scanButton, new LinearLayout.LayoutParams(0, dp(43), 1));
        bulkButton = button("批量移除", false);
        LinearLayout.LayoutParams bulkLp = new LinearLayout.LayoutParams(0, dp(43), 1);
        bulkLp.leftMargin = dp(9);
        actions.addView(bulkButton, bulkLp);
        root.addView(actions, margin(-1, dp(43), 9, 0));
        scanButton.setOnClickListener(v -> scanPackages());
        bulkButton.setOnClickListener(v -> bulkRemove());
        installButton = button("＋ 从手机选择 APK，安装到手表", true);
        root.addView(installButton, margin(-1, dp(43), 6, 0));
        installButton.setOnClickListener(v -> chooseApk());

        search = field("搜索应用名称或包名", "", false);
        root.addView(search, margin(-1, dp(42), 8, 0));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { refreshList(); }
            @Override public void afterTextChanged(Editable s) { }
        });
        LinearLayout tabs = horizontal();
        desktopTab = button("桌面应用", true);
        systemTab = button("系统预装", false);
        allTab = button("全部 App", false);
        historyTab = button("恢复记录", false);
        for (Button b : Arrays.asList(desktopTab, systemTab, allTab, historyTab)) {
            b.setTextSize(11);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(37), 1);
            lp.rightMargin = dp(4);
            tabs.addView(b, lp);
        }
        root.addView(tabs, margin(-1, dp(37), 8, 0));
        iconButton = button("读取更多真实图标（每次最多 12 个）", false);
        root.addView(iconButton, margin(-1, dp(36), 4, 0));
        iconButton.setTextSize(11);
        iconButton.setOnClickListener(v -> fetchBatchIcons());
        desktopTab.setOnClickListener(v -> switchTab(0));
        systemTab.setOnClickListener(v -> switchTab(1));
        allTab.setOnClickListener(v -> switchTab(2));
        historyTab.setOnClickListener(v -> switchTab(3));
        counter = text("连接后可查看手表不可常规卸载的预装应用", 12, MUTED, false);
        root.addView(counter, margin(-1, -2, 7, 0));
        list = new ListView(this);
        list.setBackground(shape(Color.WHITE, 10, 0xFFE0E8E7));
        list.setDividerHeight(dp(1));
        list.setCacheColorHint(Color.TRANSPARENT);
        adapter = new ListAdapter();
        list.setAdapter(adapter);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1));
        TextView footer = text("真实图标仅来自手表 APK · 读不到则显示占位图 · 核心组件禁止移除", 10, MUTED, false);
        footer.setGravity(Gravity.CENTER);
        root.addView(footer, margin(-1, -2, 6, 0));
        updateActions();
    }

    private void setStatus(String message, boolean error) {
        status.setText(message);
        status.setTextColor(error ? RED : GREEN);
        status.setBackground(shape(error ? 0xFFFCEEEE : 0xFFE8F1F0, 9, 0));
    }
    private void updateActions() {
        boolean canUse = connected && !busy && confirmedWatch;
        scanButton.setEnabled(connected && !busy);
        bulkButton.setEnabled(canUse && !selected.isEmpty() && filter != 3);
        installButton.setEnabled(canUse);
        if (iconButton != null) {
            iconButton.setVisibility(filter == 0 ? View.VISIBLE : View.GONE);
            iconButton.setEnabled(canUse && launcherKnown);
        }
        pairButton.setEnabled(!busy);
        connectButton.setEnabled(!busy);
        bulkButton.setText("批量移除" + (selected.isEmpty() ? "" : " (" + selected.size() + ")"));
    }
    private void setBusy(boolean value, String message) {
        busy = value;
        if (message != null) setStatus(message, false);
        updateActions();
        adapter.notifyDataSetChanged();
    }
    private String validIp() {
        String host = ip.getText().toString().trim();
        // Hosts must be IPv4 literals; do not forward arbitrary hostnames.
        if (!host.matches("(?:\\d{1,3}\\.){3}\\d{1,3}")) throw new IllegalArgumentException("请输入手表 IPv4 地址");
        String[] octets = host.split("\\.");
        for (String octet : octets) if (Integer.parseInt(octet) > 255) throw new IllegalArgumentException("IP 地址无效");
        return host;
    }
    private int validPort(EditText field) {
        String raw = field.getText().toString().trim();
        try {
            int port = Integer.parseInt(raw);
            if (port >= 1 && port <= 65535) return port;
        } catch (Exception ignored) { }
        throw new IllegalArgumentException("请填写正确的端口号（1–65535）");
    }
    private void saveConnection() {
        settings.edit().putString("ip", ip.getText().toString().trim())
            .putString("pair_port", pairingPort.getText().toString().trim())
            .putString("connect_port", connectPort.getText().toString().trim()).apply();
    }
    private void background(String doing, BackgroundTask task) {
        if (busy) return;
        setBusy(true, doing);
        CrashDiagnostics.start(this, doing);
        try {
            io.execute(() -> {
                try {
                    String message = task.run();
                    CrashDiagnostics.completed(getApplicationContext());
                    main.post(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        setBusy(false, null);
                        setStatus(message, false);
                    });
                } catch (Throwable failure) {
                    // LinkageError/NoClassDefFoundError from ADB, Conscrypt or SPAKE2
                    // are NOT Exceptions and escaped the V2 worker, terminating the app.
                    CrashDiagnostics.failed(getApplicationContext(), doing, failure);
                    final String msg = "操作失败：" + safeError(failure) + "。可点击【复制诊断】查看详情。";
                    main.post(() -> {
                        if (isFinishing() || isDestroyed()) return;
                        setBusy(false, null);
                        setStatus(msg, true);
                        connectionPanel.setVisibility(View.VISIBLE);
                        settingToggle.setText("连接设置 ▲");
                    });
                }
            });
        } catch (RejectedExecutionException ex) {
            CrashDiagnostics.failed(this, doing, ex);
            setBusy(false, null);
            setStatus("后台任务未能启动，请重新打开 App。", true);
        }
    }
    private String safeError(Throwable e) {
        if (e instanceof NoClassDefFoundError) {
            String missing = e.getMessage();
            return "缺少 APK 加密类" + (missing == null ? "" : "：" + missing)
                + "。请使用 V2.3 版本对齐修复版";
        }
        if (e instanceof UnsatisfiedLinkError)
            return "ADB 加密原生库无法加载，请复制诊断查看具体库名";
        if (e instanceof java.net.ConnectException)
            return "无法到达手表端口。请检查 Wi-Fi、手表无线调试和配对/连接端口";
        String s = e.getMessage();
        if (s == null || s.trim().isEmpty()) return e.getClass().getSimpleName();
        return s.length() > 190 ? s.substring(0, 190) : s;
    }
    private interface BackgroundTask { String run() throws Exception; }

    /** SAF picker: read APK from phone; only one ordinary .apk file is supported. */
    private void chooseApk() {
        if (!connected || !confirmedWatch || busy) {
            setStatus("请先通过无线 ADB 连接 Galaxy Watch 8。", true);
            return;
        }
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
        try {
            startActivityForResult(intent, APK_PICK_REQUEST);
        } catch (Exception e) {
            setStatus("无法打开手机文件选择器：" + safeError(e), true);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != APK_PICK_REQUEST || resultCode != RESULT_OK || data == null || data.getData() == null) return;
        prepareApk(data.getData());
    }

    private String documentName(Uri uri) {
        String name = null;
        try (Cursor cursor = getContentResolver().query(uri,
            new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) name = cursor.getString(0);
        } catch (Exception ignored) { }
        return name == null ? "" : name;
    }

    private void prepareApk(Uri uri) {
        final String filename = documentName(uri);
        if (!filename.toLowerCase(Locale.ROOT).endsWith(".apk")) {
            setStatus("只支持单个 .apk 文件。APKS、XAPK 和 APKM 暂不支持。", true);
            return;
        }
        background("正在从手机读取并检查 APK…", () -> {
            File local = File.createTempFile("watch8_selected_", ".apk", getCacheDir());
            try {
                long copied = 0;
                try (InputStream src = getContentResolver().openInputStream(uri);
                     FileOutputStream dest = new FileOutputStream(local)) {
                    if (src == null) throw new IllegalArgumentException("无法读取选中的 APK");
                    byte[] buf = new byte[64 * 1024];
                    int n;
                    while ((n = src.read(buf)) != -1) {
                        copied += n;
                        if (copied > MAX_APK_BYTES) throw new IllegalArgumentException("APK 超过 200MB，请使用其他安装方式");
                        dest.write(buf, 0, n);
                    }
                }
                if (local.length() < 1024) throw new IllegalArgumentException("APK 文件为空或损坏");
                PackageInfo pkgInfo = getPackageManager().getPackageArchiveInfo(local.getAbsolutePath(), 0);
                if (pkgInfo == null || !SafetyPolicy.validPackageName(pkgInfo.packageName))
                    throw new IllegalArgumentException("无法识别有效的 Android APK，可能是拆分包或文件损坏");
                final String packageName = pkgInfo.packageName;
                final String size = String.format(Locale.CHINA, "%.1f MB", local.length() / 1048576.0);
                main.post(() -> confirmApkInstall(local, filename, packageName, size));
                return "已读取 " + filename + "（" + size + "），等待确认安装。";
            } catch (Exception e) {
                if (local.exists()) local.delete();
                throw e;
            }
        });
    }

    private void confirmApkInstall(File local, String filename, String pkg, String size) {
        if (isFinishing() || isDestroyed()) { local.delete(); return; }
        new AlertDialog.Builder(this)
            .setTitle("安装到 Galaxy Watch 8？")
            .setMessage("文件：" + filename + "\n大小：" + size + "\n包名：" + pkg +
                "\n\n仅安装来自可信来源的 Wear OS APK。普通手机 APK、架构不匹配或版本不兼容可能被拒绝。" +
                "\n\n如果已有同包名应用，将尝试更新并保留数据；签名不同将被系统拒绝。")
            .setNegativeButton("取消", (d, w) -> local.delete())
            .setOnCancelListener(d -> local.delete())
            .setPositiveButton("确认安装", (d, w) -> installApk(local, pkg, filename))
            .show();
    }

    private void installApk(File local, String pkg, String filename) {
        if (!connected || !confirmedWatch || busy || !SafetyPolicy.validPackageName(pkg)) {
            local.delete();
            setStatus("已断开连接或无效包名；请重新连接手表。", true);
            return;
        }
        background("正在准备传输 APK…", () -> {
            String remote = "/data/local/tmp/w8_inst_" + UUID.randomUUID().toString().replace("-", "") + ".apk";
            try {
                if (!adb.isConnected() || !confirmedWatch) throw new IllegalStateException("手表 ADB 连接已断开");
                adb.pushApk(local, remote, (sent, total) -> {
                    final int percent = (int) (sent * 100L / total);
                    main.post(() -> { if (busy) setStatus("正在传输 " + filename + " 到手表：" + percent + "%", false); });
                });
                main.post(() -> { if (busy) setStatus("已传输完成，正在手表上安装 APK…", false); });
                WatchAdb.CommandResult installed = adb.run("pm install -r --user 0 " + remote, 150);
                if (!installed.ok() || !installed.output.contains("Success"))
                    throw new IllegalStateException("手表安装失败：" + installed.output);
                WatchAdb.CommandResult verify = adb.run("pm path " + pkg, 30);
                if (!verify.ok() || !verify.output.contains("package:"))
                    throw new IllegalStateException("安装命令返回成功，但未能验证包名：" + pkg);
                PackageScanner.ScanResult scanned = PackageScanner.scan(adb);
                applyScan(scanned);
                return "安装成功：" + pkg + "（可在全部 App 中查看）";
            } finally {
                try { if (adb.isConnected()) adb.run("rm -f " + remote, 20); } catch (Exception ignored) { }
                local.delete();
            }
        });
    }

    private void pairDevice() {
        try {
            String host = validIp();
            int port = validPort(pairingPort);
            String code = pairingCode.getText().toString().trim();
            if (!code.matches("\\d{6}")) throw new IllegalArgumentException("需要手表屏幕显示的 6 位配对码");
            saveConnection();
            background("正在通过手表的配对端口验证……", () -> {
                boolean ok = adb.pair(host, port, code);
                if (!ok) throw new IllegalStateException("配对未成功：请在手表上重新打开配对码页面，检查端口与验证码");
                main.post(() -> { if (!isFinishing() && !isDestroyed()) pairingCode.setText(""); });
                return "配对成功！接下来使用无线调试主页的连接端口，点击【连接手表】。";
            });
        } catch (Exception e) { setStatus(safeError(e), true); }
    }
    private void connectDevice() {
        try {
            String host = validIp();
            int port = validPort(connectPort);
            saveConnection();
            // Never reuse the previous device's watch verification for a new endpoint.
            connected = false;
            confirmedWatch = false;
            allItems.clear();
            launcherKnown = false;
            selected.clear();
            refreshList();
            background("正在建立手表 ADB 连接……", () -> {
                adb.connect(host, port);
                connected = adb.isConnected();
                if (!connected) throw new IllegalStateException("连接未建立；检查当前连接端口，而非配对端口");
                PackageScanner.ScanResult scanned = PackageScanner.scan(adb);
                applyScan(scanned);
                return scanned.isWatch ? "已连接手表，扫描完成。可选择要处理的预装应用。" :
                    "已连接设备，但未识别为 Wear OS 手表：只允许浏览，不允许卸载。";
            });
        } catch (Exception e) { setStatus(safeError(e), true); }
    }
    private void scanPackages() {
        if (!adb.isConnected()) { connected = false; updateActions(); setStatus("连接已断开。请重新连接手表。", true); return; }
        background("正在读取手表系统应用列表……", () -> {
            PackageScanner.ScanResult scanned = PackageScanner.scan(adb);
            applyScan(scanned);
            return "已扫描 " + scanned.items.size() + " 个手表 App。" +
                (scanned.isWatch ? "" : "设备不是手表，已禁用删除操作。 ");
        });
    }
    private void applyScan(PackageScanner.ScanResult scanned) {
        main.post(() -> {
            confirmedWatch = scanned.isWatch;
            device.setText("当前设备：" + scanned.deviceModel + (scanned.isWatch ? " · Wear OS 手表" : " · 未确认手表身份"));
            allItems.clear();
            allItems.addAll(scanned.items);
            launcherKnown = scanned.launcherKnown;
            Map<String, String> aliases = aliases();
            for (PackageInfoItem item : allItems) {
                if (aliases.containsKey(item.name)) item.label = aliases.get(item.name);
            }
            selected.clear();
            refreshList();
            updateActions();
            // The scanner's completion callback is queued immediately after applyScan.
            // Queue icon reading behind it so it never starts while the scan is busy.
            if (scanned.isWatch && scanned.launcherKnown) main.post(this::autoFetchInitialIcons);
        });
    }
    private void switchTab(int next) {
        filter = next;
        selected.clear();
        Button[] buttons = {desktopTab, systemTab, allTab, historyTab};
        for (int i = 0; i < buttons.length; ++i) {
            buttons[i].setBackground(shape(next == i ? GREEN : Color.WHITE, 10, next == i ? 0 : 0xFFD3E2DF));
            buttons[i].setTextColor(next == i ? Color.WHITE : GREEN);
        }
        refreshList(); updateActions();
    }
    private void refreshList() {
        if (adapter == null) return;
        shown.clear();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        if (filter == 3) {
            for (HistoryStore.Entry e : history.entries().values()) {
                if (!e.pkg.toLowerCase(Locale.ROOT).contains(q) && !e.label.toLowerCase(Locale.ROOT).contains(q)) continue;
                boolean pending = true;
                for (PackageInfoItem item : allItems) {
                    if (!item.name.equals(e.pkg)) continue;
                    // Disabled packages remain installed; deleted packages do not.
                    pending = "disable".equals(e.operation) ? item.disabled : false;
                    break;
                }
                if (pending) shown.add(new DisplayRow(null, e));
            }
        } else {
            for (PackageInfoItem item : allItems) {
                if (filter == 0 && !item.launcher) continue;
                if (filter == 1 && !item.system) continue;
                if (!item.name.toLowerCase(Locale.ROOT).contains(q) &&
                    !item.label.toLowerCase(Locale.ROOT).contains(q)) continue;
                shown.add(new DisplayRow(item, null));
            }
        }
        counter.setText(filter == 3 ? "本机恢复记录：" + shown.size() + " 项" :
            filter == 0 && !launcherKnown ? "未能验证手表桌面入口；请用「全部 App」或重试扫描（不猜测）。" :
            "显示 " + shown.size() + " 项 · " + (filter == 0 ? "手表桌面入口" : "手表安装包") +
            " · 点击名称查看详细信息");
        if (filter == 0 || filter == 1 || filter == 2) {
            // Chinese-friendly sorting makes the app drawer easier to cross-reference.
            final java.text.Collator collator = java.text.Collator.getInstance(Locale.CHINA);
            shown.sort((a, b) -> collator.compare(a.item.label, b.item.label));
        }
        adapter.notifyDataSetChanged();
        updateActions();
    }

    private Map<String, String> aliases() {
        java.util.Map<String, String> result = new java.util.HashMap<>();
        try {
            JSONObject obj = new JSONObject(settings.getString("aliases", "{}"));
            java.util.Iterator<String> iter = obj.keys();
            while (iter.hasNext()) {
                String key = iter.next(); result.put(key, obj.optString(key, key));
            }
        } catch (Exception ignored) { }
        return result;
    }
    private void showDetails(PackageInfoItem item) {
        boolean iconLoaded = RemoteIconStore.hasCached(this, item.name);
        String message = "名称：" + item.label + "\n"
            + "完整包名：" + item.name + "\n"
            + "类别：" + (item.system ? "系统预装" : "第三方安装") + "\n"
            + "桌面入口：" + (!launcherKnown ? "尚未验证" : (item.launcher ? "有" : "无已识别入口")) + "\n"
            + "风险：" + SafetyPolicy.status(item.level) + "\n"
            + "图标：" + (iconLoaded ? "已从手表 APK 提取" : "目前为占位图标") + "\n\n"
            + "删除前请核对完整包名。系统预装应用可能依赖其他组件。";
        new AlertDialog.Builder(this).setTitle("手表应用详情")
            .setMessage(message)
            .setNegativeButton("关闭", null)
            .setNeutralButton("修改中文备注", (d, w) -> renamePackage(item))
            .setPositiveButton(iconLoaded ? "重新读取图标" : "读取实际图标", (d, w) -> fetchActualIcon(item))
            .show();
    }
    /** Downloads only the selected package, never all 279 watch system APKs. */
    private String readActualIcon(PackageInfoItem item) throws Exception {
        if (!confirmedWatch || !SafetyPolicy.validPackageName(item.name))
            throw new IllegalStateException("手表身份或包名验证失败");
        WatchAdb.CommandResult path = adb.run("pm path --user 0 " + item.name, 25);
        path.requireSuccess();
        String remote = null;
        for (String line : path.output.split("\\r?\\n")) {
            if (line.startsWith("package:") && line.substring(8).trim().endsWith(".apk")) {
                remote = line.substring(8).trim();
                if (remote.endsWith("/base.apk")) break;
            }
        }
        if (remote == null) throw new IllegalStateException("手表没有提供可读取的 APK 路径");
        File temp = File.createTempFile("w8_icon_", ".apk", getCacheDir());
        try {
            adb.pullIconApk(remote, temp);
            return RemoteIconStore.extract(this, item.name, temp);
        } finally { temp.delete(); }
    }
    private void updateExtractedLabel(PackageInfoItem item, String newLabel) {
        if (!isFinishing() && !isDestroyed()) {
            if (!aliases().containsKey(item.name) && newLabel != null && !newLabel.isEmpty())
                item.label = newLabel;
            refreshList();
        }
    }
    private void fetchActualIcon(PackageInfoItem item) {
        if (!connected || !confirmedWatch || busy) {
            setStatus("请先连接手表并确认设备身份。", true);
            return;
        }
        iconFailures.remove(item.name);
        background("正在读取 " + item.label + " 的手表实际图标……", () -> {
            String newLabel = readActualIcon(item);
            main.post(() -> updateExtractedLabel(item, newLabel));
            return "已从手表 APK 读取图标：" + item.name;
        });
    }
    /** First connection/scan automatically resolves a SMALL batch of the displayed watch icons. */
    private void autoFetchInitialIcons() {
        if (!connected || !confirmedWatch || busy || !launcherKnown || filter != 0) return;
        List<PackageInfoItem> targets = pendingIconTargets(INITIAL_ICON_BATCH);
        if (targets.isEmpty()) return;
        runIconBatch(targets, true);
    }

    private List<PackageInfoItem> pendingIconTargets(int max) {
        List<PackageInfoItem> targets = new ArrayList<>();
        for (DisplayRow row : shown) {
            if (row.item != null && row.item.launcher &&
                !RemoteIconStore.hasCached(this, row.item.name) &&
                !iconFailures.contains(row.item.name)) {
                targets.add(row.item);
                if (targets.size() >= max) break;
            }
        }
        return targets;
    }

    /** Additional batches require a tap to avoid fetching every system APK. */
    private void fetchBatchIcons() {
        if (!connected || !confirmedWatch || busy || !launcherKnown) {
            setStatus("请先完成手表连接并扫描「桌面应用」。", true);
            return;
        }
        List<PackageInfoItem> targets = pendingIconTargets(MANUAL_ICON_BATCH);
        if (targets.isEmpty()) {
            setStatus("当前桌面图标已读取，或剩余项目无法自动提取；可点应用名称逐个重试。", false);
            return;
        }
        new AlertDialog.Builder(this).setTitle("继续读取手表真实图标？")
            .setMessage("将读取 " + targets.size() + " 个桌面应用的 APK 并提取图标。" +
                "每个 APK 上限 30MB；遇到权限或资源限制将保留占位图。" +
                "请保持手表无线调试和 Wi-Fi 连接。")
            .setNegativeButton("取消", null)
            .setPositiveButton("开始读取", (d, w) -> runIconBatch(targets, false))
            .show();
    }

    private void runIconBatch(List<PackageInfoItem> targets, boolean automatic) {
        background(automatic ? "正在自动读取首批手表真实图标……" :
            "正在读取更多手表真实图标……", () -> {
            int loaded = 0, skipped = 0;
            String firstFailure = "";
            for (int i = 0; i < targets.size(); ++i) {
                // Only ADB sync pull & PackageManager archive extraction; never remove apps here.
                PackageInfoItem item = targets.get(i);
                final int step = i + 1;
                main.post(() -> setStatus("正在读取真实图标 " + step + "/" + targets.size() +
                    "：" + item.label, false));
                try {
                    String label = readActualIcon(item);
                    loaded++;
                    main.post(() -> updateExtractedLabel(item, label));
                } catch (Exception error) {
                    skipped++;
                    iconFailures.add(item.name);
                    if (firstFailure.isEmpty())
                        firstFailure = item.label + "：" + safeError(error);
                }
            }
            String result = (automatic ? "首批真实图标" : "真实图标") +
                "：成功 " + loaded + "，未读取 " + skipped +
                "。可点「读取更多真实图标」继续。";
            if (!firstFailure.isEmpty()) result += " 首个失败原因：" + firstFailure;
            return result;
        });
    }
    private void renamePackage(PackageInfoItem item) {
        EditText name = field("输入自定义应用名称", item.label, false);
        LinearLayout box = vertical(); box.setPadding(dp(20), dp(12), dp(20), dp(3)); box.addView(name);
        new AlertDialog.Builder(this).setTitle("给应用添加中文备注")
            .setMessage(item.name).setView(box).setNegativeButton("取消", null)
            .setPositiveButton("保存", (d, w) -> {
                String value = name.getText().toString().trim();
                if (value.isEmpty() || value.length() > 50) return;
                try {
                    JSONObject obj = new JSONObject(settings.getString("aliases", "{}"));
                    obj.put(item.name, value);
                    settings.edit().putString("aliases", obj.toString()).apply();
                    item.label = value;
                    refreshList();
                } catch (Exception ignored) { }
            }).show();
    }
    private boolean mayChange(PackageInfoItem item) {
        return !busy && connected && confirmedWatch &&
            item != null && item.level != SafetyPolicy.Level.PROTECTED;
    }
    private void removeOne(PackageInfoItem item) {
        if (!mayChange(item)) return;
        new AlertDialog.Builder(this)
            .setTitle("确认从手表用户环境移除？")
            .setMessage("应用：" + item.label + "\n包名：" + item.name +
                "\n风险：" + SafetyPolicy.status(item.level) + "\n\n" + (item.system ? "这是预装系统应用。误删可能影响手表功能、健康或通知；恢复也不保证成功。\n\n" : "") +
                "执行 pm uninstall --user 0；不会永久擦除系统分区文件。")
            .setNegativeButton("取消", null)
            .setPositiveButton("确认移除", (d, w) -> runRemove(item))
            .show().getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(RED);
    }
    private void runRemove(PackageInfoItem item) {
        background("正在移除：" + item.label, () -> {
            // Repeat safety check on worker thread; no arbitrary package injection.
            if (!confirmedWatch || item.level == SafetyPolicy.Level.PROTECTED ||
                !SafetyPolicy.validPackageName(item.name)) throw new IllegalStateException("禁止操作核心组件或无效包名");
            WatchAdb.CommandResult result = adb.run("pm uninstall --user 0 " + item.name);
            if (!result.ok() || !result.output.contains("Success"))
                throw new IllegalStateException("系统拒绝卸载：" + result.output);
            history.record(item.name, item.label, "remove");
            PackageScanner.ScanResult scanned = PackageScanner.scan(adb);
            applyScan(scanned);
            return "已从手表用户 0 移除 " + item.label + "，可以在恢复记录中尝试恢复。";
        });
    }
    private void moreActions(PackageInfoItem item) {
        String[] actions = item.disabled ? new String[]{"复制包名", "修改中文备注", "重新启用", "查看详情 / 读取实际图标"} :
            new String[]{"复制包名", "修改中文备注", "停用应用（保留安装）", "查看详情 / 读取实际图标"};
        new AlertDialog.Builder(this).setTitle(item.label).setItems(actions, (d, which) -> {
            if (which == 0) {
                ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
                clipboard.setPrimaryClip(ClipData.newPlainText("Watch8 package", item.name));
                Toast.makeText(this, "包名已复制", Toast.LENGTH_SHORT).show();
            } else if (which == 1) renamePackage(item);
            else if (which == 3) showDetails(item);
            else if (mayChange(item)) confirmToggle(item);
            else setStatus("核心组件已保护，禁止停用。", true);
        }).show();
    }
    private void confirmToggle(PackageInfoItem item) {
        boolean enabling = item.disabled;
        String op = enabling ? "启用" : "停用";
        new AlertDialog.Builder(this).setTitle("确认" + op + "？")
            .setMessage(item.label + "\n" + item.name + "\n操作可能影响手表功能。")
            .setNegativeButton("取消", null)
            .setPositiveButton(op, (d, w) -> background("正在" + op + item.label + "……", () -> {
                if (!confirmedWatch || item.level == SafetyPolicy.Level.PROTECTED)
                    throw new IllegalStateException("该应用受到保护");
                String command = enabling ? "pm enable --user 0 " : "pm disable-user --user 0 ";
                WatchAdb.CommandResult result = adb.run(command + item.name);
                result.requireSuccess();
                if (enabling) history.remove(item.name);
                else history.record(item.name, item.label, "disable");
                applyScan(PackageScanner.scan(adb));
                return item.label + " 已" + op;
            })).show();
    }
    private void bulkRemove() {
        List<PackageInfoItem> batch = new ArrayList<>();
        for (PackageInfoItem item : allItems)
            if (selected.contains(item.name) && mayChange(item)) batch.add(item);
        if (batch.isEmpty()) { setStatus("请先勾选可以移除的应用。", true); return; }
        StringBuilder detail = new StringBuilder("将依次尝试移除 " + batch.size() + " 个应用：\n");
        for (int i = 0; i < Math.min(10, batch.size()); ++i)
            detail.append("• ").append(batch.get(i).label).append("\n");
        if (batch.size() > 10) detail.append("……\n");
        detail.append("\n系统组件删除存在风险，且不保证都可恢复；请逐项核对包名。");
        new AlertDialog.Builder(this).setTitle("批量移除确认")
            .setMessage(detail.toString()).setNegativeButton("取消", null)
            .setPositiveButton("执行", (d, w) -> background("正在批量处理，请勿断开无线调试……", () -> {
                if (!confirmedWatch) throw new IllegalStateException("当前设备不是已确认手表");
                int success = 0;
                List<String> failed = new ArrayList<>();
                for (PackageInfoItem item : batch) {
                    if (!SafetyPolicy.validPackageName(item.name) ||
                        item.level == SafetyPolicy.Level.PROTECTED) { failed.add(item.label); continue; }
                    try {
                        WatchAdb.CommandResult r = adb.run("pm uninstall --user 0 " + item.name);
                        if (r.ok() && r.output.contains("Success")) {
                            history.record(item.name, item.label, "remove");
                            success++;
                        } else failed.add(item.label + " (系统拒绝)");
                    } catch (Exception ex) { failed.add(item.label + " (" + safeError(ex) + ")"); }
                }
                applyScan(PackageScanner.scan(adb));
                return "批量处理：成功 " + success + "，失败 " + failed.size() +
                    (failed.isEmpty() ? "" : "；失败项：" + String.join("、", failed));
            })).show();
    }
    private void restore(HistoryStore.Entry entry) {
        if (!connected || !confirmedWatch || busy || !SafetyPolicy.validPackageName(entry.pkg)) return;
        String action = "disable".equals(entry.operation) ? "pm enable --user 0 " :
            "cmd package install-existing --user 0 ";
        new AlertDialog.Builder(this).setTitle("恢复手表应用")
            .setMessage("应用：" + entry.label + "\n包名：" + entry.pkg +
                "\n\n系统原始 APK 必须仍在设备上；部分组件无法通过该方式恢复。")
            .setNegativeButton("取消", null)
            .setPositiveButton("尝试恢复", (d, w) -> background("正在尝试恢复 " + entry.label, () -> {
                WatchAdb.CommandResult r = adb.run(action + entry.pkg);
                r.requireSuccess();
                if (r.output.toLowerCase(Locale.ROOT).contains("failure") ||
                    r.output.toLowerCase(Locale.ROOT).contains("error:"))
                    throw new IllegalStateException("恢复失败：" + r.output);
                PackageScanner.ScanResult check = PackageScanner.scan(adb);
                boolean restored = false;
                for (PackageInfoItem item : check.items) {
                    if (item.name.equals(entry.pkg) &&
                        (!"disable".equals(entry.operation) || !item.disabled)) {
                        restored = true;
                        break;
                    }
                }
                if (!restored) throw new IllegalStateException("已尝试恢复，但手表应用清单未确认成功；保留恢复记录");
                history.remove(entry.pkg);
                applyScan(check);
                return "已确认恢复：" + entry.label;
            })).show();
    }

    private static final class DisplayRow {
        final PackageInfoItem item;
        final HistoryStore.Entry history;
        DisplayRow(PackageInfoItem item, HistoryStore.Entry history) {
            this.item = item; this.history = history;
        }
    }
    private final class ListAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int index, View oldView, ViewGroup parent) {
            DisplayRow row = shown.get(index);
            PackageInfoItem item = row.item;
            boolean recovery = row.history != null;
            LinearLayout container = horizontal();
            container.setPadding(dp(9), dp(10), dp(8), dp(10));
            if (!recovery) {
                CheckBox check = new CheckBox(MainActivity.this);
                check.setButtonTintList(android.content.res.ColorStateList.valueOf(GREEN));
                check.setChecked(selected.contains(item.name));
                check.setEnabled(!busy && connected && confirmedWatch &&
                    item.level != SafetyPolicy.Level.PROTECTED);
                check.setOnCheckedChangeListener((v, checked) -> {
                    if (checked) selected.add(item.name); else selected.remove(item.name);
                    updateActions();
                });
                container.addView(check, margin(dp(39), dp(42), 0, 4));
            } else {
                TextView restoreIcon = text("↺", 23, GREEN, true);
                restoreIcon.setGravity(Gravity.CENTER);
                container.addView(restoreIcon, margin(dp(40), dp(42), 0, 4));
            }
            if (!recovery) {
                ImageView icon = new ImageView(MainActivity.this);
                Drawable actual = RemoteIconStore.cachedIcon(MainActivity.this, item.name);
                if (actual != null) icon.setImageDrawable(actual);
                else icon.setImageDrawable(RemoteIconStore.placeholder(MainActivity.this, item.label, item.system));
                icon.setContentDescription(actual == null ? "分类占位图标，非手表实际图标" : "从手表 APK 读取的实际图标");
                LinearLayout.LayoutParams iconLp = margin(dp(35), dp(35), 0, 5);
                container.addView(icon, iconLp);
            }
            LinearLayout info = vertical();
            TextView name = text(recovery ? row.history.label : item.label, 14, TEXT, true);
            name.setSingleLine(true); name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            info.addView(name);
            TextView pkg = text(recovery ? row.history.pkg : item.name, 10, MUTED, false);
            pkg.setSingleLine(true); pkg.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            info.addView(pkg, margin(-1, -2, 2, 0));
            String tag = recovery ? ("disable".equals(row.history.operation) ? "停用记录" : "移除记录") :
                SafetyPolicy.status(item.level) + (item.launcher ? " · 桌面可见" : "") +
                (item.disabled ? " · 已停用" : "");
            TextView risk = text(tag, 10, !recovery && item.level == SafetyPolicy.Level.PROTECTED ? RED : MUTED, false);
            info.addView(risk, margin(-1, -2, 2, 0));
            container.addView(info, new LinearLayout.LayoutParams(0, -2, 1));
            if (!recovery) info.setOnClickListener(v -> showDetails(item));
            Button action = button(recovery ? "恢复" :
                item.level == SafetyPolicy.Level.PROTECTED ? "保护" : "移除", false);
            action.setTextColor(!recovery && item.level == SafetyPolicy.Level.PROTECTED ? MUTED : GREEN);
            LinearLayout.LayoutParams alp = margin(dp(60), dp(39), 0, 0);
            alp.leftMargin = dp(5);
            container.addView(action, alp);
            action.setEnabled(!busy && connected && confirmedWatch &&
                (recovery || item.level != SafetyPolicy.Level.PROTECTED));
            action.setOnClickListener(v -> { if (recovery) restore(row.history); else removeOne(item); });
            if (!recovery) container.setOnLongClickListener(v -> { moreActions(item); return true; });
            return container;
        }
    }

    private static final class Endpoint {
        final String label, address, type; final int port;
        Endpoint(String label, String address, int port, String type) {
            this.label = label; this.address = address; this.port = port; this.type = type;
        }
    }
    @SuppressWarnings("deprecation")
    private void autoDiscover() {
        if (discovering) return;
        if (nsd == null) { setStatus("系统不支持自动发现，请手动输入手表 IP 和端口。", true); return; }
        discovered.clear(); discovering = true;
        setStatus("正在搜索同一 Wi-Fi 中的 ADB 配对/连接服务……", false);
        discoverPair = makeDiscovery("pair");
        discoverConnect = makeDiscovery("connect");
        try { nsd.discoverServices("_adb-tls-pairing._tcp.", NsdManager.PROTOCOL_DNS_SD, discoverPair); }
        catch (Exception ignored) { discoverPair = null; }
        try { nsd.discoverServices("_adb-tls-connect._tcp.", NsdManager.PROTOCOL_DNS_SD, discoverConnect); }
        catch (Exception ignored) { discoverConnect = null; }
        main.postDelayed(this::finishDiscovery, 10000);
    }
    @SuppressWarnings("deprecation")
    private NsdManager.DiscoveryListener makeDiscovery(String type) {
        return new NsdManager.DiscoveryListener() {
            @Override public void onDiscoveryStarted(String s) { }
            @Override public void onServiceFound(NsdServiceInfo service) {
                try { nsd.resolveService(service, new NsdManager.ResolveListener() {
                    @Override public void onResolveFailed(NsdServiceInfo info, int errorCode) { }
                    @Override public void onServiceResolved(NsdServiceInfo resolved) {
                        if (resolved.getHost() == null || resolved.getPort() < 1) return;
                        String address = resolved.getHost().getHostAddress();
                        if (!address.matches("(?:\\d{1,3}\\.){3}\\d{1,3}")) return;
                        Endpoint endpoint = new Endpoint(resolved.getServiceName(),
                            address, resolved.getPort(), type);
                        main.post(() -> {
                            for (Endpoint old : discovered) if (old.address.equals(endpoint.address) &&
                                old.port == endpoint.port) return;
                            discovered.add(endpoint);
                        });
                    }
                }); } catch (Exception ignored) { /* Another NSD resolution may be active. */ }
            }
            @Override public void onServiceLost(NsdServiceInfo service) { }
            @Override public void onDiscoveryStopped(String serviceType) { }
            @Override public void onStartDiscoveryFailed(String serviceType, int errorCode) {
                try { nsd.stopServiceDiscovery(this); } catch (Exception ignored) { }
            }
            @Override public void onStopDiscoveryFailed(String serviceType, int errorCode) { }
        };
    }
    @SuppressWarnings("deprecation")
    private void finishDiscovery() {
        if (!discovering) return;
        discovering = false;
        try { if (discoverPair != null) nsd.stopServiceDiscovery(discoverPair); } catch (Exception ignored) { }
        try { if (discoverConnect != null) nsd.stopServiceDiscovery(discoverConnect); } catch (Exception ignored) { }
        discoverPair = null; discoverConnect = null;
        if (isFinishing() || isDestroyed()) return;
        if (discovered.isEmpty()) {
            setStatus("没有发现手表。请确认无线调试已开启，并手动填写手表 IP 和两个不同端口。", true);
            return;
        }
        String[] labels = new String[discovered.size()];
        for (int i = 0; i < discovered.size(); ++i) {
            Endpoint e = discovered.get(i);
            labels[i] = (e.type.equals("pair") ? "配对" : "连接") + " · " +
                e.address + ":" + e.port + " · " + e.label;
        }
        new AlertDialog.Builder(this).setTitle("选择手表调试服务")
            .setItems(labels, (d, which) -> {
                Endpoint e = discovered.get(which);
                ip.setText(e.address);
                if (e.type.equals("pair")) pairingPort.setText(String.valueOf(e.port));
                else connectPort.setText(String.valueOf(e.port));
                saveConnection();
                connectionPanel.setVisibility(View.VISIBLE);
                settingToggle.setText("连接设置 ▲");
                setStatus(e.type.equals("pair") ? "已填入配对端口，请输入手表 6 位配对码。" :
                    "已填入连接端口；配对过的设备可以直接点击连接手表。", false);
            }).show();
    }
    @Override protected void onDestroy() {
        finishDiscovery();
        io.shutdownNow();
        adb.shutdown();
        super.onDestroy();
    }
}
