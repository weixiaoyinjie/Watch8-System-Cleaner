# Watch8 应用管理器 V2.7：自动加载真实图标修复版

**本次原因**：用户提供的 `app-debug.apk` 内没有“桌面应用 / 读取手表桌面图标”代码，仍为旧版本。仅上传源码 ZIP 不会改变手机已安装的 APK。必须使用新版工作流重新编译，安装新版手机端 APK。

## 改动

1. 首页明确显示 `V2.7 自动图标版`，方便肉眼核实版本。第一次连接并完成扫描后默认打开【桌面应用】，显示有 LAUNCHER 入口的手表 App，附中文名和完整包名。
2. 自动读取首批最多 **6** 个桌面应用图标。图标是从手表远程 APK 提取后在手机缓存，不使用通用网络搜索图，也不会伪装为真实图标。后台状态会逐个显示读图进度。
3. 可点【读取更多真实图标】每次读取最多 **12** 个。读取失败项不自动反复重试；点击具体应用名称 →【读取实际图标】可单独重试并看到错误。
4. 在【系统预装】【全部 App】也能显示已经缓存的实际图标；其余显示有文字的明确占位图。
5. 由于资源提取和 ADB 权限限制，一些预装 APK 可能无法读取真实图标；单个 APK 大于 30MB 会跳过，不能保证 100% 图标。
6. 保留已有无线调试连接 / 配对 / 自动发现、扫描、APK 安装、批量移除、恢复、备注和风险保护功能。没有降低原先系统核心组件的操作保护。

## 现有 GitHub 仓库 OneUpload 编译

1. 打开仓库 https://github.com/weixiaoyinjie/Watch8-System-Cleaner/upload/main ，把 **Watch8_System_Manager_V2_7_AutoIcons_OneUpload.zip** 直接上传根目录（此仓库的 workflow 会自动解压它，不必手动解压）。
2. 打开 https://github.com/weixiaoyinjie/Watch8-System-Cleaner/edit/main/.github/workflows/build-apk.yml ，把文件内容替换成同包提供的 `build-apk.yml`，或使用额外下载的 `Watch8_V2_7_build-apk.yml`，提交修改。
3. 在 Actions 运行 `Build Watch8 Manager V2.7 Auto Icons APK`，下载构建产物 `Watch8-Manager-V2.7-AutoIcons-Phone-APK`，安装里面的 **app-debug.apk** 到手机。
4. 启动后 **先核实副标题写 `V2.7 自动图标版`**。如果仍显示旧版标题，说明手机还是旧 APK；请确认下载的 Actions 产物版本。尽量覆盖安装以保留历史记录；Android 签名不同时可能要求卸载旧版本，但卸载会导致本地配对资料和恢复记录丢失。

**安全**：不要依据推测中文名直接移除系统包。请核对完整包名。移除系统预装 App 可能破坏通知、健康监控、系统 UI 等功能。

**验证**：源代码和 ZIP 文件结构已检查。当前环境没有 Android SDK/Gradle，未进行完整 Android 编译，也未进行 Galaxy Watch8 真机读取验证。`verify_apk_crypto.py` 和新增加的 V2.7 DEX 字符串校验会在 GitHub Actions 内执行。
