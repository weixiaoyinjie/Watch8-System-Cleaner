package com.watch8.cleaner;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import io.github.muntashirakon.adb.AdbStream;

/** ADB client executes commands on the WATCH, not the phone. Do not use on UI thread. */
public final class WatchAdb {
    private final Context context;
    private final ScheduledExecutorService watchdog = Executors.newSingleThreadScheduledExecutor();

    public WatchAdb(Context context) { this.context = context.getApplicationContext(); }

    private AdbIdentity identity() throws Exception { return AdbIdentity.get(context); }

    public void pair(String ip, int pairingPort, String sixDigitCode) throws Exception {
        identity().pair(ip, pairingPort, sixDigitCode);
    }
    public void connect(String ip, int connectionPort) throws Exception {
        if (identity().isConnected()) identity().disconnect();
        identity().connect(ip, connectionPort);
    }
    public void disconnect() throws Exception { identity().disconnect(); }
    public boolean isConnected() {
        try { return identity().isConnected(); } catch (Exception e) { return false; }
    }

    public synchronized CommandResult run(String command) throws Exception {
        if (!isConnected()) throw new IllegalStateException("手表尚未连接。请检查无线调试端口。");
        // A random marker separates shell exit status from all command output.
        final String sentinel = "__W8_EXIT_" + UUID.randomUUID().toString().replace("-", "") + "__";
        final String wrapped = "(" + command + ") 2>&1; echo " + sentinel + "$?";
        final AdbStream stream = identity().openStream("shell:" + wrapped);
        ScheduledFuture<?> timeout = watchdog.schedule(() -> {
            try { stream.close(); } catch (Exception ignored) { }
        }, 22, TimeUnit.SECONDS);
        try {
            ByteArrayOutputStream data = new ByteArrayOutputStream(8192);
            byte[] buf = new byte[8192];
            InputStream in = stream.openInputStream();
            String text = "";
            boolean complete = false;
            while (true) {
                int size = in.read(buf);
                if (size == -1) break;
                if (size == 0) continue;
                data.write(buf, 0, size);
                if (data.size() > 3_000_000) throw new IllegalStateException("设备输出超过 3MB，已终止读取");
                text = data.toString("UTF-8");
                // Wait for end of the exit code; ADB packets can split strings.
                if (Pattern.compile(Pattern.quote(sentinel) + "[0-9]+(?:\\r?\\n|$)").matcher(text).find()) {
                    complete = true;
                    break;
                }
            }
            if (!complete) throw new IllegalStateException("指令未完成或连接已超时；请重新连接手表。");
            Matcher match = Pattern.compile(Pattern.quote(sentinel) + "(\\d+)").matcher(text);
            if (!match.find()) throw new IllegalStateException("无法获得指令执行结果");
            int code = Integer.parseInt(match.group(1));
            return new CommandResult(code, text.substring(0, match.start()).trim());
        } finally {
            timeout.cancel(false);
            try { stream.close(); } catch (Exception ignored) { }
        }
    }

    public void shutdown() { watchdog.shutdownNow(); }

    public static final class CommandResult {
        public final int exitCode;
        public final String output;
        CommandResult(int exitCode, String output) { this.exitCode = exitCode; this.output = output; }
        public boolean ok() { return exitCode == 0; }
        public void requireSuccess() {
            if (!ok()) throw new IllegalStateException(output.isEmpty() ? "指令执行失败，退出码：" + exitCode : output);
        }
    }
}
