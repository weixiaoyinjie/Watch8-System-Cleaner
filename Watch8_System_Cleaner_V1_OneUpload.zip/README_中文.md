# Watch8 System Cleaner v1.0（手机端）

## 能做什么

- **只安装手机 APK**，Samsung Galaxy Watch 8 不需要安装 APK，无需 Root 或电脑。
- 通过无线 ADB（SPAKE2 6 位码配对 + TLS 连接）在手机上读取**手表**的系统预装应用和用户应用。
- 列表展示应用名称（内置常见映射）、**真实包名**、系统/普通分类、风险等级和已停用状态。
- 搜索、批量勾选、逐个移除、批量移除；长按应用行可停用/重新启用或复制包名。
- 自动发现局域网 ADB 配对/连接端口；也可以手动填写端口，更可靠。
- **恢复记录**：尝试重新安装手表系统分区保留的包，或者启用之前停用的 App。
- 自动识别手表特征，误连到普通手机时仅允许浏览，不允许卸载。
- 核心系统包默认禁止移除。不能识别用途的系统包标记为“需谨慎”，不会标记为“安全”。
- 未上传应用列表，操作记录仅保存在手机的 App 私有存储中。

## 使用方法

1. 手机和 Galaxy Watch 8 连接同一 Wi-Fi。
2. 手表设置 → 开发者选项 → 无线调试 → 打开。若没有开发者选项，在“关于手表 → 软件信息”中多次点击软件版本以开启。
3. 在手表的“通过配对码配对设备”页面读取 **手表 IP、配对端口、6 位配对码**，填写到手机应用中，点击**进行配对**。也可用“自动找手表”尝试自动填写端口。
4. 返回手表无线调试**主页面**，找到 `IP:连接端口`，填入手机 App 的“连接端口”。**注意：连接端口和配对端口不同，不能交换**。
5. 点击**连接手表**。成功后扫描系统预装应用，搜索包名、勾选或点击“移除”即可。
6. 如果误删，进入“恢复记录”，尝试点击“恢复”。不保证每个系统包均能恢复。

## 重要说明

- 系统应用移除使用 `pm uninstall --user 0 <package>`；**仅从手表当前用户环境移除**，不擦除只读系统分区中的原始 APK。
- 恢复主要使用 `cmd package install-existing --user 0 <package>`；停用/重新启用使用 `pm disable-user --user 0` 与 `pm enable --user 0`。
- 某些三星受保护的应用会拒绝卸载；某些恢复也可能失败，严重误删可能需要重置手表。
- “可点击移除”**不等于“安全删除”**；非核心名单仅是保护的下限，实际存在依赖关系，需自行谨慎核对包名。
- 通过 ADB 远程管理设备是高权限操作。只在可信 Wi-Fi 使用，操作后建议关闭手表无线调试。
- 即使配对已经保存，**每次手表重启或无线调试服务重新启动，连接端口都可能变化**，需要更新。
- 部分应用名称可能以包名末段显示，点名称可添加中文备注。本版本不会伪装为已经读取真实应用图标或所有系统包的资源名称。
- 目前为**源码项目**，尚未经真实 Galaxy Watch 8 连机验证。需要 GitHub Actions 编译并上表测试。

## 通过 GitHub 编译安装 APK（无需本机 Android Studio）

1. 建一个空的 GitHub 仓库，建议命名 `Watch8-System-Cleaner`。
2. 解压 ZIP 后，把**压缩包内部的所有文件和目录**上传到仓库根目录，包括隐藏的 `.github/workflows/build-apk.yml` 文件。GitHub 网页批量上传隐藏目录可能不方便，可用 GitHub 网页新建文件，名字输入 `.github/workflows/build-apk.yml`，粘贴该文件内容。
3. 打开 GitHub **Actions → Build Watch8 System Cleaner APK → Run workflow**。若仓库未开放 Actions，按页面提示启用。
4. 编译成功后进入该次运行页面最下方的 **Artifacts**，下载 `Watch8-System-Cleaner-v1-debug-apk`，解压得到 `app-debug.apk`，安装在**手机上**。

项目使用 Gradle 8.9 / Android Gradle Plugin 8.7.3 / JDK 17 / compileSdk 35。
构建时需要联网从 Google Maven、Maven Central 与 JitPack 获取开源依赖。

## 源码结构

- `MainActivity.java`：纯原生 Android UI、操作确认、批量移除、恢复及 mDNS 端口发现。
- `WatchAdb.java`：通过 TLS ADB 发送 shell 命令、超时处理、解析退出码。
- `AdbIdentity.java`：生成并保存 ADB RSA 私钥 + X.509 证书。
- `PackageScanner.java`：只查询手表用户 0 的 PackageManager。
- `SafetyPolicy.java`：核心包拦截、未知系统包谨慎标记、常见应用名称。
- `HistoryStore.java`：手机本地恢复记录。
- `.github/workflows/build-apk.yml`：云端 APK 编译。

## 来源 / 依赖

无线 ADB 基于开源 `MuntashirAkon/libadb-android`（JitPack 3.1.1），TLS 基于 Conscrypt，X509 证书基于 Bouncy Castle。遵守相应开源许可证。应用的自行编写业务代码为演示参考，适用于个人设备管理。
