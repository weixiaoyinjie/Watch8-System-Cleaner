# Watch8 应用管理器 V2.5 PackagingFix

修复 V2.4 GitHub Actions `:app:mergeDebugJavaResource` 编译失败：Bouncy Castle 1.81 的多个 JAR 包含同名 `META-INF/versions/9/OSGI-INF/MANIFEST.MF`。

## 具体修复
- `app/build.gradle` 中新增 `packaging.resources.excludes += ['META-INF/versions/**']`，排除 Android 不使用的 Java 9+ 多版本 JAR 资源，以避免重复元数据冲突。
- 继续使用已经可以解析的 Bouncy Castle `bcprov-jdk18on`、`bcpkix-jdk18on`、`bcutil-jdk18on` 1.81。
- 保留 V2.4 的加密类、SPAKE2 和 Conscrypt 本地库校验，避免无法正常配对的 APK 被上传。
- 保持手表系统 App 管理、批量移除、恢复记录、安装 APK、无线配对和复制诊断等功能。

## GitHub 操作
1. 将 `Watch8_System_Manager_V2_5_PackagingFix_OneUpload.zip` 不解压，上传至 `weixiaoyinjie/Watch8-System-Cleaner` 仓库 `main` 分支根目录。
2. 打开 `.github/workflows/build-apk.yml`，用 `Watch8_PackagingFix_V2_5_build-apk.yml` 中完整代码替换并提交。
3. 在 Actions 中选择 `Build Watch8 Manager V2.5 PackagingFix APK` 运行工作流。
4. 成功后从 Artifacts 下载 `Watch8-Manager-V2.5-PackagingFix-Phone-APK`。

## 测试范围
已完成 ZIP、YAML、Shell 语法及源文件检查；尚未实际通过 GitHub 编译或真机配对，待 Actions 结果验证。
