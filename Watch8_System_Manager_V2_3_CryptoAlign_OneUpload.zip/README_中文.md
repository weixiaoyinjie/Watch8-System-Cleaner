# Watch8 System Manager V2.3 · CryptoAlign

## 对应修复

GitHub 日志已确认 V2.2 的 Gradle 编译通过，但末尾 APK 加密检查失败。
libadb-android 3.1.1 的 Gradle 配置依赖 `bcprov-jdk15to18:1.81`。
旧 V2.2 直接声明 bcprov、bcpkix、bcutil 为 1.78.1，存在版本不一致；V2.3 三者统一为 1.81。

此版将 APK 验证改为检查程序实际用于证书生成和 TLS 配对的类，
而不是无条件要求所有 ASN.1 OID 注册表都在 DEX 中。
验证依然检查 `libspake2.so` 和 `libconscrypt_jni.so` 是否实际打入 arm64 APK。
编译前打印解析后的依赖清单，发现过时版本会中断；使用 clean 编译避免旧产物。

## 上传及编译

1. 将 `Watch8_System_Manager_V2_3_CryptoAlign_OneUpload.zip` 原样上传 GitHub 仓库根目录。
2. 把 `.github/workflows/build-apk.yml` 替换为配套的 `Watch8_CryptoAlign_V2_3_build-apk.yml` 内容。
3. GitHub Actions 编译后，若显示绿色成功，下载名为
   `Watch8-Manager-V2.3-CryptoAlign-Phone-APK` 的构建产物。

注意：已完成 ZIP、源码和 YAML 的静态校验，但当前环境没有 Android SDK，
无法保证真机配对已经通过。第一次连接时要区分配对端口与连接端口。
如果配对仍失败，请点击“复制诊断”，发送错误信息（不要包含 6 位配对码）。

保留：系统应用扫描、禁用/卸载和恢复记录、第三方 APK 发送安装功能。
危险系统组件的删除应谨慎操作。
