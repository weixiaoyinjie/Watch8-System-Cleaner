# Watch8 应用管理器 V2.4 CryptoDeps

修复 V2.3 编译错误：`checkDebugAarMetadata` 阶段无法解析 `org.bouncycastle:bcpkix-jdk15to18:1.81` 与 `bcutil-jdk15to18:1.81`。

## 修复内容
- 把 Bouncy Castle 依赖统一为 Maven Central 的 `bcprov-jdk18on:1.81`、`bcpkix-jdk18on:1.81`、`bcutil-jdk18on:1.81`。
- 排除 libadb 间接引入的 `bcprov-jdk15to18`，避免混合依赖造成重复类。
- 保留 APK 中 ADB 加密类和 arm64 本地库校验，只有成功才允许上传 APK。
- 保留既有 UI、手表应用管理、系统预装应用操作、恢复记录、第三方 APK 安装、错误诊断与无线配对流程。

## GitHub 一次上传并编译
1. 上传 `Watch8_System_Manager_V2_4_CryptoDeps_OneUpload.zip` 至仓库 main 分支根目录，不解压。
2. 将 `.github/workflows/build-apk.yml` 内容整体替换为 `Watch8_CryptoDeps_V2_4_build-apk.yml` 代码并提交。
3. Actions 自动触发编译，或手动选择 `Build Watch8 Manager V2.4 CryptoDeps APK` 并 Run workflow。
4. 编译和 APK 内部加密类检查全部通过后，在 Artifacts 下载 `Watch8-Manager-V2.4-CryptoDeps-Phone-APK`。

## 注意
静态检查不等于运行时已验证；V2.4 仍需使用真机测试配对。如仍失败，使用应用的「复制诊断」功能获取具体原因。
