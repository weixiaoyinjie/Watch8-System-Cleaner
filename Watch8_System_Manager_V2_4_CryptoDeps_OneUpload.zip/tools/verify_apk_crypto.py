#!/usr/bin/env python3
"""Verify that essential certificate-generation and ADB TLS/SPAKE2 classes are defined in the APK."""
import sys
import struct
import zipfile

EXPECTED_TYPES = {
    # Actual certificate-generation API used by AdbIdentity.
    # Do not gate APK upload on unrelated ASN.1 OID registry classes.
    'Lorg/bouncycastle/asn1/ASN1ObjectIdentifier;',
    'Lorg/bouncycastle/asn1/x500/X500Name;',
    'Lorg/bouncycastle/cert/jcajce/JcaX509v3CertificateBuilder;',
    'Lorg/bouncycastle/cert/jcajce/JcaX509CertificateConverter;',
    'Lorg/bouncycastle/operator/jcajce/JcaContentSignerBuilder;',
    'Lorg/conscrypt/Conscrypt;',
    'Lorg/bouncycastle/jce/provider/BouncyCastleProvider;',
    'Lio/github/muntashirakon/adb/AbsAdbConnectionManager;',
}
EXPECTED_ARM64_LIBS = {
    'lib/arm64-v8a/libspake2.so',
    'lib/arm64-v8a/libconscrypt_jni.so',
}


def dex_defined_classes(data):
    if not data.startswith(b'dex\n'):
        raise ValueError('Invalid DEX magic')
    unpack = lambda at: struct.unpack_from('<I', data, at)[0]
    strings_off, strings_count = unpack(0x3c), unpack(0x38)
    strings = []
    for i in range(strings_count):
        offset = unpack(strings_off + 4 * i)
        while data[offset] & 0x80:  # uleb128 utf16-length prefix
            offset += 1
        offset += 1
        stop = data.index(b'\0', offset)
        strings.append(data[offset:stop].decode('utf-8', errors='replace'))
    types_off, types_count = unpack(0x44), unpack(0x40)
    types = [strings[unpack(types_off + 4 * i)] for i in range(types_count)]
    classes_off, classes_count = unpack(0x64), unpack(0x60)
    return {types[unpack(classes_off + i * 32)] for i in range(classes_count)}


def validate(apk):
    with zipfile.ZipFile(apk) as archive:
        names = set(archive.namelist())
        dex_files = sorted(x for x in names if x.startswith('classes') and x.endswith('.dex'))
        if not dex_files:
            raise RuntimeError('No classes.dex in APK')
        definitions = set()
        for name in dex_files:
            definitions.update(dex_defined_classes(archive.read(name)))
    absent = EXPECTED_TYPES - definitions
    absent_libs = EXPECTED_ARM64_LIBS - names
    if absent or absent_libs:
        for cls in sorted(absent):
            print('MISSING CLASS:', cls, file=sys.stderr)
        for lib in sorted(absent_libs):
            print('MISSING NATIVE LIB:', lib, file=sys.stderr)
        raise SystemExit('FAILED: APK cannot pass ADB crypto packaging check')
    print(f'PASS: {len(EXPECTED_TYPES)} crypto classes defined across '
          f'{len(dex_files)} DEX files; required arm64 native libraries included.')


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Usage: python3 tools/verify_apk_crypto.py path/to/app-debug.apk')
    validate(sys.argv[1])
