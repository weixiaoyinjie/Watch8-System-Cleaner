# Watch8 应用管理器 V2.6：中文名称 + 桌面应用识别 + 图标 + 风险保护

**适用**：Galaxy Watch8 (Wear OS) 的手机端 ADB 应用管理器。保留 V2.5 的无线配对、自动发现、扫描、单个 APK 安装、批量移除、停用/启用、恢复记录、复制诊断。

## 本次新增
1. 新的【桌面应用】标签：用远端手表的 `ACTION_MAIN`/`CATEGORY_LAUNCHER` 实际查询，不按包名猜测。若固件不支持查询则显示“未能验证”，不要误当空列表。
2. 【系统预装】【全部 App】【恢复记录】仍然存在。所有页面显示中文名称（已知准确包名优先匹配）、完整包名、风险分级。
3. 初始图标是**带首字的分类占位图，不代表手表原始图标**。点应用名称进入详情，点【读取实际图标】会从手表单独读取 APK 并提取。桌面页还可一次按需读取最多 12 个图标。
4. 单个 APK 读取上限 30 MiB；权限受限、体积过大的 APK 会跳过并保留占位图。已读图标会缓存到手机，不会把 APK 长期保存在手机。部分拆分 APK 资源无法通过 base.apk 提取，会明确报错。
5. 核心组件仍然禁止移除和停用；Android 系统资源覆盖层额外保护。其余系统包一律标高风险，不宣称安全。
6. 支持中文备注，按中文名排序和搜索，也可搜索完整包名。

## 安装与测试
- **注意**：本源码生成的是 **手机端 APK**，手表不需要安装此管理端。
- 本版使用原有 `applicationId` (`com.watch8.cleaner`) 及版号 `2.6.0`。如果 GitHub Actions 的 Debug 签名与当前安装版不同，Android 可能禁止覆盖安装。**不要直接卸载旧版**；请先考虑保留旧版数据和恢复记录，重新配对、卸载重装会丢失 App 本地记录。
- Android 11+ 连接手表无线调试：配对端口（含 6 位验证码）与连接端口是两个不同端口。已配对后可直接用连接端口。
- 首次扫描若无法识别桌面入口，请在【全部 App】按包名搜索，勿凭空猜测图标。
- 本版本未在实体 Galaxy Watch8 上验证 ADB 图标提取兼容性。

## GitHub 现有仓库构建（一次上传源码 ZIP）
1. 下载并将 `Watch8_System_Manager_V2_6_ChineseIcons_OneUpload.zip` **不解压**上传到已有仓库 `weixiaoyinjie/Watch8-System-Cleaner` 的根目录，覆盖同名文件。
2. 打开 `.github/workflows/build-apk.yml`，将其内容换成额外提供的 `Watch8_V2_6_build-apk.yml`（下载后复制全文即可），提交到 main。
3. 在 **Actions** → `Build Watch8 Manager V2.6 Chinese Icons APK` → `Run workflow`。
4. 成功后在 **Artifacts** 下载 `Watch8-Manager-V2.6-ChineseIcons-Phone-APK`，里面的 `app-debug.apk` 即手机安装包。

## 技术验证声明
已检查源代码、ZIP 文件结构和必要类、工作流文本；此执行环境没有 Android SDK/Gradle，**未完成实际 APK 编译或真机验证**，请以 GitHub Actions 结果为准。原始上传的 APK 未被改动。
