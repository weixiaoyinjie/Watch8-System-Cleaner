package com.watch8.cleaner;

import android.content.Context;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import io.github.muntashirakon.adb.AdbStream;

/** ADB client executes commands on the WATCH, not the phone. Do not use on UI thread. */
public final class WatchAdb {
    private final Context context;
    private final ScheduledExecutorService watchdog = Executors.newSingleThreadScheduledExecutor();

    public WatchAdb(Context context) { this.context = context.getApplicationContext(); }

    private AdbIdentity identity() throws Exception { return AdbIdentity.get(context); }

    public boolean pair(String ip, int pairingPort, String sixDigitCode) throws Exception {
        return identity().pair(ip, pairingPort, sixDigitCode);
    }
    public void connect(String ip, int connectionPort) throws Exception {
        if (identity().isConnected()) identity().disconnect();
        if (!identity().connect(ip, connectionPort) && !identity().isConnected())
            throw new IllegalStateException("ADB 连接失败，请检查手表的连接端口和 Wi-Fi");
    }
    public void disconnect() throws Exception { identity().disconnect(); }
    public boolean isConnected() {
        try { return identity().isConnected(); } catch (Exception e) { return false; }
    }

    public synchronized CommandResult run(String command) throws Exception {
        return run(command, 22);
    }

    public synchronized CommandResult run(String command, int timeoutSeconds) throws Exception {
        if (!isConnected()) throw new IllegalStateException("手表尚未连接。请检查无线调试端口。");
        // A random marker separates shell exit status from all command output.
        final String sentinel = "__W8_EXIT_" + UUID.randomUUID().toString().replace("-", "") + "__";
        final String wrapped = "(" + command + ") 2>&1; echo " + sentinel + "$?";
        final AdbStream stream = identity().openStream("shell:" + wrapped);
        ScheduledFuture<?> timeout = watchdog.schedule(() -> {
            try { stream.close(); } catch (Exception ignored) { }
        }, timeoutSeconds, TimeUnit.SECONDS);
        try {
            ByteArrayOutputStream data = new ByteArrayOutputStream(8192);
            byte[] buf = new byte[8192];
            InputStream in = stream.openInputStream();
            String text = "";
            boolean complete = false;
            while (true) {
                int size = in.read(buf);
                if (size == -1) break;
                if (size == 0) continue;
                data.write(buf, 0, size);
                if (data.size() > 3_000_000) throw new IllegalStateException("设备输出超过 3MB，已终止读取");
                text = data.toString("UTF-8");
                // Wait for end of the exit code; ADB packets can split strings.
                if (Pattern.compile(Pattern.quote(sentinel) + "[0-9]+(?:\\r?\\n|$)").matcher(text).find()) {
                    complete = true;
                    break;
                }
            }
            if (!complete) throw new IllegalStateException("指令未完成或连接已超时；请重新连接手表。");
            Matcher match = Pattern.compile(Pattern.quote(sentinel) + "(\\d+)").matcher(text);
            if (!match.find()) throw new IllegalStateException("无法获得指令执行结果");
            int code = Integer.parseInt(match.group(1));
            return new CommandResult(code, text.substring(0, match.start()).trim());
        } finally {
            timeout.cancel(false);
            try { stream.close(); } catch (Exception ignored) { }
        }
    }

    /**
     * Push a single APK using the real ADB sync: SEND/DATA/DONE protocol.
     * Uses constant-size buffers; never loads the complete APK in RAM.
     * Only an app-generated, fixed /data/local/tmp path is permitted.
     */
    public synchronized void pushApk(File apk, String remotePath, ProgressListener progress) throws Exception {
        if (!isConnected()) throw new IllegalStateException("请先连接手表");
        if (!remotePath.matches("/data/local/tmp/w8_inst_[a-f0-9]{32}\\.apk"))
            throw new IllegalArgumentException("无效的临时文件路径");
        if (!apk.isFile() || apk.length() < 1024) throw new IllegalArgumentException("APK 文件无效或为空");
        final AdbStream stream = identity().openStream("sync:");
        ScheduledFuture<?> timeout = watchdog.schedule(() -> {
            try { stream.close(); } catch (Exception ignored) { }
        }, 300, TimeUnit.SECONDS);
        try {
            OutputStream out = stream.openOutputStream();
            InputStream in = stream.openInputStream();
            byte[] pathMode = (remotePath + ",33188").getBytes(StandardCharsets.UTF_8); // 0100644
            sendSyncHeader(out, "SEND", pathMode.length);
            out.write(pathMode);
            byte[] buf = new byte[64 * 1024];
            long sent = 0, total = apk.length();
            int lastPercent = -1;
            try (FileInputStream fileIn = new FileInputStream(apk)) {
                int n;
                while ((n = fileIn.read(buf)) != -1) {
                    if (n == 0) continue;
                    sendSyncHeader(out, "DATA", n);
                    out.write(buf, 0, n);
                    sent += n;
                    int percent = (int)(sent * 100 / total);
                    if (percent != lastPercent && progress != null) {
                        lastPercent = percent;
                        progress.onProgress(sent, total);
                    }
                }
            }
            sendSyncHeader(out, "DONE", (int)(System.currentTimeMillis() / 1000L));
            out.flush();
            byte[] ack = new byte[8];
            readExactly(in, ack);
            String id = new String(ack, 0, 4, StandardCharsets.US_ASCII);
            int len = ByteBuffer.wrap(ack, 4, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
            if ("OKAY".equals(id)) return;
            if ("FAIL".equals(id)) {
                if (len < 0 || len > 8192) throw new IllegalStateException("同步失败，错误长度无效");
                byte[] err = new byte[len];
                readExactly(in, err);
                throw new IllegalStateException("传输失败：" + new String(err, StandardCharsets.UTF_8));
            }
            throw new IllegalStateException("ADB 同步未确认完成：" + id);
        } finally {
            timeout.cancel(false);
            try { stream.close(); } catch (Exception ignored) { }
        }
    }

    /**
     * Read one explicitly selected watch APK to extract its icon on the phone.
     * ADB sync STAT is checked before RECV: large system packages are rejected.
     * Never reads more than 30 MiB and never persists the original APK.
     */
    public synchronized void pullIconApk(String remotePath, File destination) throws Exception {
        if (!isConnected()) throw new IllegalStateException("手表 ADB 未连接");
        if (remotePath == null || remotePath.length() > 512 ||
            !remotePath.startsWith("/") || !remotePath.endsWith(".apk") ||
            remotePath.contains("..") ||
            !remotePath.matches("/[a-zA-Z0-9_./~+=@-]+"))
            throw new IllegalArgumentException("APK 路径不符合安全要求");
        final long MAX_PULL = 30L * 1024 * 1024;
        final AdbStream stream = identity().openStream("sync:");
        ScheduledFuture<?> timeout = watchdog.schedule(() -> {
            try { stream.close(); } catch (Exception ignored) { }
        }, 110, TimeUnit.SECONDS);
        try {
            OutputStream out = stream.openOutputStream();
            InputStream in = stream.openInputStream();
            byte[] path = remotePath.getBytes(StandardCharsets.UTF_8);
            sendSyncHeader(out, "STAT", path.length);
            out.write(path); out.flush();
            byte[] stat = new byte[16];
            readExactly(in, stat);
            String statId = new String(stat, 0, 4, StandardCharsets.US_ASCII);
            if (!"STAT".equals(statId)) throw new IllegalStateException("手表 ADB 不支持 APK 大小查询");
            long apkSize = Integer.toUnsignedLong(ByteBuffer.wrap(stat, 8, 4)
                .order(ByteOrder.LITTLE_ENDIAN).getInt());
            if (apkSize < 1024 || apkSize > MAX_PULL)
                throw new IllegalStateException("APK 大小为 " + (apkSize / 1048576) +
                    " MB；为保护速度，只读取不超过 30MB 的实际图标");
            sendSyncHeader(out, "RECV", path.length);
            out.write(path); out.flush();
            long received = 0;
            try (FileOutputStream file = new FileOutputStream(destination)) {
                while (true) {
                    byte[] header = new byte[8];
                    readExactly(in, header);
                    String id = new String(header, 0, 4, StandardCharsets.US_ASCII);
                    int length = ByteBuffer.wrap(header, 4, 4)
                        .order(ByteOrder.LITTLE_ENDIAN).getInt();
                    if ("DONE".equals(id)) break;
                    if ("FAIL".equals(id)) {
                        if (length < 0 || length > 8192) throw new IllegalStateException("读取失败，返回长度异常");
                        byte[] error = new byte[length]; readExactly(in, error);
                        throw new IllegalStateException("手表拒绝读取：" + new String(error, StandardCharsets.UTF_8));
                    }
                    if (!"DATA".equals(id) || length < 1 || length > 65536 ||
                        received + length > MAX_PULL)
                        throw new IllegalStateException("ADB 传输数据异常或 APK 太大");
                    byte[] chunk = new byte[length];
                    readExactly(in, chunk);
                    file.write(chunk);
                    received += length;
                }
            }
            if (received != apkSize) throw new IllegalStateException("手表 APK 传输不完整");
        } catch (Exception ex) {
            destination.delete();
            throw ex;
        } finally {
            timeout.cancel(false);
            try { stream.close(); } catch (Exception ignored) { }
        }
    }

    private static void sendSyncHeader(OutputStream out, String cmd, int size) throws Exception {
        if (cmd.length() != 4) throw new IllegalArgumentException("ADB sync command is not 4 bytes");
        byte[] header = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
            .put(cmd.getBytes(StandardCharsets.US_ASCII)).putInt(size).array();
        out.write(header);
    }

    private static void readExactly(InputStream in, byte[] buffer) throws Exception {
        int offset = 0;
        while (offset < buffer.length) {
            int n = in.read(buffer, offset, buffer.length - offset);
            if (n < 0) throw new java.io.EOFException("ADB sync response incomplete");
            if (n > 0) offset += n;
        }
    }

    public interface ProgressListener { void onProgress(long bytesSent, long totalBytes); }

    public void shutdown() { watchdog.shutdownNow(); }

    public static final class CommandResult {
        public final int exitCode;
        public final String output;
        CommandResult(int exitCode, String output) { this.exitCode = exitCode; this.output = output; }
        public boolean ok() { return exitCode == 0; }
        public void requireSuccess() {
            if (!ok()) throw new IllegalStateException(output.isEmpty() ? "指令执行失败，退出码：" + exitCode : output);
        }
    }
}
