package com.watch8.cleaner;

import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;

import java.io.File;
import java.io.FileOutputStream;

/** Locally caches icons extracted only from watch APKs explicitly requested by the user. */
public final class RemoteIconStore {
    private static File cachePath(Context context, String pkg) {
        File dir = new File(context.getCacheDir(), "watch8_real_icons");
        if (!dir.isDirectory()) dir.mkdirs();
        return new File(dir, pkg + ".png");
    }

    public static boolean hasCached(Context context, String pkg) {
        return SafetyPolicy.validPackageName(pkg) && cachePath(context, pkg).isFile();
    }

    public static Drawable cachedIcon(Context context, String pkg) {
        if (!hasCached(context, pkg)) return null;
        try {
            BitmapFactory.Options options = new BitmapFactory.Options();
            options.inSampleSize = 1;
            Bitmap bitmap = BitmapFactory.decodeFile(cachePath(context, pkg).getAbsolutePath(), options);
            return bitmap != null ? new BitmapDrawable(context.getResources(), bitmap) : null;
        } catch (Exception ignored) { return null; }
    }

    /** Returns actual archive app label where it is distinguishable from the package ID. */
    @SuppressWarnings("deprecation")
    public static String extract(Context context, String expectedPkg, File localApk) throws Exception {
        if (!SafetyPolicy.validPackageName(expectedPkg)) throw new IllegalArgumentException("包名无效");
        PackageManager manager = context.getPackageManager();
        PackageInfo info = manager.getPackageArchiveInfo(localApk.getAbsolutePath(), PackageManager.GET_ACTIVITIES);
        if (info == null || !expectedPkg.equals(info.packageName) || info.applicationInfo == null)
            throw new IllegalStateException("读取到的 APK 与所选手表包名不一致");
        ApplicationInfo app = info.applicationInfo;
        app.sourceDir = localApk.getAbsolutePath();
        app.publicSourceDir = localApk.getAbsolutePath();
        Drawable drawable = null;
        if (app.icon != 0 || app.roundIcon != 0) drawable = app.loadIcon(manager);
        // Some Wear apps declare their launcher icon only at activity level.
        if (drawable == null && info.activities != null) {
            for (ActivityInfo activity : info.activities) {
                if (activity.icon == 0) continue;
                activity.applicationInfo = app;
                drawable = activity.loadIcon(manager);
                if (drawable != null) break;
            }
        }
        if (drawable == null) throw new IllegalStateException("该手表 APK 未提供可读取的独立图标");
        Bitmap bitmap = Bitmap.createBitmap(144, 144, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        drawable.setBounds(0, 0, 144, 144);
        drawable.draw(canvas);
        File png = cachePath(context, expectedPkg);
        try (FileOutputStream output = new FileOutputStream(png)) {
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, output))
                throw new IllegalStateException("保存图标失败");
        } finally { bitmap.recycle(); }
        CharSequence label = app.loadLabel(manager);
        String name = label == null ? "" : label.toString().trim();
        return name.equals(expectedPkg) ? "" : name;
    }

    /** An intentionally generic initial tile, clearly not a claim about the real Watch icon. */
    public static Drawable placeholder(Context context, String label, boolean system) {
        final String first = label == null || label.isEmpty() ? "?" :
            label.substring(0, label.offsetByCodePoints(0, 1)).toUpperCase(java.util.Locale.ROOT);
        final int bg = system ? 0xFF477A78 : 0xFF446DAB;
        return new Drawable() {
            private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
            @Override public void draw(Canvas canvas) {
                android.graphics.Rect b = getBounds();
                float size = Math.min(b.width(), b.height());
                float cx = b.exactCenterX(), cy = b.exactCenterY();
                paint.setColor(bg); paint.setStyle(Paint.Style.FILL);
                canvas.drawRoundRect(cx-size/2, cy-size/2, cx+size/2, cy+size/2, size*.25f, size*.25f, paint);
                paint.setColor(Color.WHITE); paint.setTextAlign(Paint.Align.CENTER);
                paint.setTextSize(size * .53f); paint.setFakeBoldText(true);
                canvas.drawText(first, cx, cy - (paint.ascent() + paint.descent())/2, paint);
            }
            @Override public void setAlpha(int alpha) { }
            @Override public void setColorFilter(ColorFilter filter) { }
            @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
        };
    }
    private RemoteIconStore() { }
}
