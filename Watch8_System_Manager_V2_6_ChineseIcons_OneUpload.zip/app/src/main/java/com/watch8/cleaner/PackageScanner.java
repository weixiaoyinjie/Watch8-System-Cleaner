package com.watch8.cleaner;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/** Queries the WATCH via ADB. Does not scan local phone apps. */
public final class PackageScanner {
    public static final class ScanResult {
        public final List<PackageInfoItem> items;
        public final String deviceModel;
        public final boolean isWatch;
        public final boolean launcherKnown;
        ScanResult(List<PackageInfoItem> items, String deviceModel, boolean isWatch, boolean launcherKnown) {
            this.items = items; this.deviceModel = deviceModel; this.isWatch = isWatch;
            this.launcherKnown = launcherKnown;
        }
    }
    private static Set<String> packages(String output) {
        Set<String> set = new HashSet<>();
        for (String line : output.split("\\r?\\n")) {
            if (!line.startsWith("package:")) continue;
            String pkg = line.substring(8).trim();
            if (SafetyPolicy.validPackageName(pkg)) set.add(pkg);
        }
        return set;
    }

    public static ScanResult scan(WatchAdb adb) throws Exception {
        String model = adb.run("getprop ro.product.model").output.trim();
        String characteristics = adb.run("getprop ro.build.characteristics").output;
        String features = adb.run("pm list features").output;
        boolean watch = characteristics.contains("watch") || features.contains("android.hardware.type.watch");

        WatchAdb.CommandResult systemResult = adb.run("pm list packages -s --user 0");
        systemResult.requireSuccess();
        WatchAdb.CommandResult userResult = adb.run("pm list packages -3 --user 0");
        userResult.requireSuccess();
        Set<String> system = packages(systemResult.output);
        Set<String> user = packages(userResult.output);
        Set<String> disabled = new HashSet<>();
        try { disabled = packages(adb.run("pm list packages -d --user 0").output); }
        catch (Exception ignored) { }
        Map<String, PackageInfoItem> all = new HashMap<>();
        for (String pkg : system) all.put(pkg, new PackageInfoItem(pkg, true));
        for (String pkg : user) all.put(pkg, new PackageInfoItem(pkg, false));
        for (String pkg : disabled) if (all.containsKey(pkg)) all.get(pkg).disabled = true;
        // Query the actual Watch OS launcher intent; do not infer desktop icons from package names.
        // Different firmware builds accept different CLI aliases, so try both documented forms.
        Set<String> launchers = new HashSet<>();
        boolean launcherKnown = false;
        String[] launcherQueries = {
            "cmd package query-activities --brief --components --user 0 -a android.intent.action.MAIN -c android.intent.category.LAUNCHER",
            "pm query-activities --brief --components --user 0 -a android.intent.action.MAIN -c android.intent.category.LAUNCHER"
        };
        for (String query : launcherQueries) {
            try {
                WatchAdb.CommandResult r = adb.run(query, 35);
                if (!r.ok()) continue;
                java.util.regex.Matcher m = java.util.regex.Pattern.compile(
                    "([a-zA-Z_][a-zA-Z0-9_]*(?:\\.[a-zA-Z0-9_]+)+)/[a-zA-Z0-9_.$]+"
                ).matcher(r.output);
                while (m.find()) if (all.containsKey(m.group(1))) launchers.add(m.group(1));
                if (!launchers.isEmpty()) { launcherKnown = true; break; }
            } catch (Exception ignored) { /* No launcher results is not evidence of no icons. */ }
        }
        for (String pkg : launchers) all.get(pkg).launcher = true;
        List<PackageInfoItem> items = new ArrayList<>(all.values());
        Collections.sort(items, (a, b) -> {
            int group = Boolean.compare(b.system, a.system);
            return group != 0 ? group : a.name.compareToIgnoreCase(b.name);
        });
        return new ScanResult(items, model, watch, launcherKnown);
    }
    private PackageScanner() { }
}
