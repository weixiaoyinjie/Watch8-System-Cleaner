package com.watch8.cleaner;

import android.app.Application;
import java.security.Security;
import org.conscrypt.Conscrypt;

public class CleanerApplication extends Application {
    @Override public void onCreate() {
        super.onCreate();
        // Android wireless debugging requires TLS 1.3 during ADB pairing and connection.
        Security.insertProviderAt(Conscrypt.newProvider(), 1);
    }
}
