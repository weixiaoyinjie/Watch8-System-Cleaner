# Watch8 应用管理器 V2 · 手机端

> 从 Watch8 System Cleaner V1 整合升级：**卸载不能常规卸载的手表预装 App + 安装第三方 Wear OS APK**。仅手机端安装本管理器，手表不需要管理端。没有 Root 和电脑要求；但首次必须完成无线 ADB 配对。

## 功能

- **安装第三方手表 App**：在手机选择单个 `.apk` 文件，确认文件名、包名及大小后，通过 ADB `sync:` 协议传输到手表 `/data/local/tmp/`，在手表执行 `pm install -r --user 0`，检查安装结果，最后清理临时 APK。显示传输进度，自动刷新列表。
- **扫描**：读取 Galaxy Watch 8 系统应用和第三方应用列表、包名及停用状态，搜索，支持常见中文名称映射、自定义备注。
- **移除系统预装 App**：确认后 `pm uninstall --user 0 包名`，不擦除只读系统分区，部分组件会拒绝卸载。
- **批量移除、停用/启用**：支持批量勾选，长按列表项可停用、启用、复制包名。
- **恢复记录**：对于系统分区保留的包，尝试 `cmd package install-existing --user 0`；停用的包尝试重新启用。恢复不是绝对保证。
- **风险防护**：保护核心系统组件；不认识的预装应用一律标记为“需谨慎”。误连普通手机只可浏览，不允许修改。
- **自动发现**：尝试发现 ADB 配对或连接的局域网端口；可手动输入更稳定。手机本地保存连接资料和恢复历史，不联网上传数据。

## 使用方法

1. 手机与 Galaxy Watch 8 连接相同 Wi-Fi。手表打开 **设置 → 开发者选项 → 无线调试**。
2. 首次打开“通过配对码配对设备”，将 **手表 IP、配对端口、6 位配对码**填入手机端，点击“进行配对”。
3. 回到手表无线调试首页，读取 **IP:连接端口**（和配对端口不是一个端口），点击“连接手表”。以后通常只需连接，但端口可能变化。
4. **安装**：点击主页绿色的 **“＋ 从手机选择 APK，安装到手表”** → 手机文件管理器选择 `.apk` → 检查包名和提示 → 确认安装。显示传输进度，成功后在“全部 App”列表查看。
5. **删除**：扫描后在“系统预装”列表找到需要处理的应用 → 点击“移除”或勾选批量移除 → 确认。核心应用受到保护。
6. 完成后建议关闭手表的无线调试。

## 安装限制

- 仅单个普通 `.apk`；**不支持 `.apks`、`.apkm`、`.xapk` 或多个拆分 APK 一起安装**。
- 200MB 以内的 APK。读取文件采用 Android 系统文件选择器（SAF），**无需读取整个手机存储的权限**。传输采用 64KB 分块，不将整个文件载入内存。
- APK 必须兼容 Wear OS 的 Android 版本、架构、功能及安装策略。**不是所有手机 APK 都能在手表运行**。签名不匹配、版本或架构不兼容、存储不足和设备限制会使安装失败。
- 从可信来源获取 APK。安装失败时 App 展示手表回传的错误信息。手表临时文件在安装完成或失败后都会尽量清理。
- ADB 首次配对必需，不能一键绕过；连接成功后，安装无需手表端接收程序。

## GitHub 编译（复用原仓库）

仓库名称：`Watch8-System-Cleaner`。为了避免上次遇到的 `does not contain a Gradle build` 问题，**可以直接上传完整 ZIP，无需解压**，只需确保 workflow 文件是本版本。

1. 打开 `https://github.com/weixiaoyinjie/Watch8-System-Cleaner`。
2. 将本文件的压缩包 `Watch8_System_Manager_V2_OneUpload.zip` 上传到仓库根目录，保持文件名不变。旧 V1 ZIP 可以保留，不影响新构建。
3. 编辑 `.github/workflows/build-apk.yml`，替换为 V2 压缩包内相同路径的代码（或单独下载的编译 YAML）。它会优先解压 V2 ZIP，再执行 Gradle。
4. 进入 **Actions → Build Watch8 Manager APK → Run workflow**。
5. 编译成功后在 **Artifacts** 下载 `Watch8-Manager-v2-phone-debug-APK`，解压得到手机用的 `app-debug.apk`。

> 也可以把 ZIP 内的 Gradle 文件和 `app/` 文件夹直接上传至仓库根目录；workflow 会跳过 ZIP 解压。**不要只上传 ZIP 而继续使用旧版“不解压”的工作流。**

## 升级 / 数据保留

- 应用包名沿用 `com.watch8.cleaner`，原 V1 记录和 ADB 配对信息可以在**签名一致**的覆盖安装时保留。
- 不同 GitHub Actions 构建可能使用不同的调试签名，如果 Android 提示“签名不一致/无法安装更新”，可能需要先卸载旧版再装新版，这会丢失手机本机的记录和配对密钥，需要重新配对。手表已安装的 App 不受影响。

## 项目文件

- `app/src/main/java/com/watch8/cleaner/MainActivity.java`：安装 APK 选择、确认、进度、原有卸载和恢复界面。
- `app/src/main/java/com/watch8/cleaner/WatchAdb.java`：无线 ADB TLS 连接、sync 文件上传和 shell 操作。
- `app/src/main/java/com/watch8/cleaner/AdbIdentity.java`：保存 RSA 密钥和证书，支持再次连接。
- `app/src/main/java/com/watch8/cleaner/PackageScanner.java`：查询手表 App。
- `app/src/main/java/com/watch8/cleaner/SafetyPolicy.java`：核心组件保护。
- `.github/workflows/build-apk.yml`：支持 ZIP 自动解压、Gradle 构建。

## 测试说明

这是完整 Android 源码项目，尚未实际在 Galaxy Watch 8 上联机测试；当前环境未安装 Android SDK，**没有声称已经编译成功或已经生成 APK**。应以 GitHub Actions 结果和手表实际安装反馈为准。
