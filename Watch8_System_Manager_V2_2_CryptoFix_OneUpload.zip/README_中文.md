# Watch8 应用管理器 V2.2.0 ADB 配对加密依赖修复 · 手机端

> 从 Watch8 System Cleaner V1 整合升级：**卸载不能常规卸载的手表预装 App + 安装第三方 Wear OS APK**。仅手机端安装本管理器，手表不需要管理端。没有 Root 和电脑要求；但首次必须完成无线 ADB 配对。

## V2.2.0 修复要点：解决 NoClassDefFoundError

在用户实际编译安装的 V2.1.1 APK 中，对所有 DEX 文件进行类型定义检查后发现：
`org.bouncycastle.asn1.oiw.OIWObjectIdentifiers`、`EdECObjectIdentifiers` 等 **13 个 Bouncy Castle ASN.1 类存在引用但没有定义**。
这与手机截图显示的 `NoClassDefFoundError` 符合，说明至少存在缺失的加密依赖。截图未显示完整堆栈，仍需新版 APK 实机验证。

- 显式添加 `org.bouncycastle:bcutil-jdk15to18:1.78.1`，与 `bcprov` / `bcpkix` **完全同版本**。
- 在生成 ADB 私钥/证书之前预检上述关键类，发现依赖缺失时清晰报错，而非单纯提示“底层加密错误”。
- 新增 `tools/verify_apk_crypto.py`，在 **APK 编译完成后**检查 DEX 中实际定义了相应 Bouncy Castle、Conscrypt 和 ADB 类，并检查 arm64 SPAKE2/Conscrypt 动态库。检查不通过不发布 APK。
- GitHub Actions 复用 Ubuntu 预安装的 Android SDK 35，不再调用尝试安装过时 `tools` 包的 `android-actions/setup-android@v3`。
- 保留 V2.1.1 的配对结果校验、异常诊断、系统 App 管理和单 APK 安装功能。

**不需要在手表安装管理端 APK。** 必须先在手机和手表上打开无线调试、完成配对，再连接当前连接端口。

## V2.1.1 已保留的防闪退改进

- **修复潜在闪退入口**：V2 的配对/连接后台仅捕获 `Exception`；本版同时处理 ADB/TLS/SPAKE2 触发的 `LinkageError` 等 `Throwable`，将可处理的底层错误展示在 App 中，而不是任由线程报错退出。
- **严格检查配对结果**：配对客户端返回 `false` 时不再提示“配对成功”。6 位配对码仅在确认成功后清空。
- **增加设备诊断**：连接设置面板新增“复制诊断”，可复制最新异常的错误堆栈，并在系统支持时读取 Android 上次进程异常退出原因（包括 JNI native crash）。不保存 6 位配对码。
- **原有功能保留**：系统 App 列表、删除/停用/批量/恢复、选择单个 APK 安装到手表均保留。
- **GitHub 上传防旧版编译**：全新工作流检测到 V2.2.0 修复包时强制解压覆盖仓库旧代码。

**说明：尚未获得用户手机的 Android logcat，因此不能证明此次闪退的唯一根因。** 若是原生 C/C++ 进程级 SIGSEGV/SIGABRT，Java 的 `catch` 不能阻止系统终止进程；请重开 App，复制诊断记录，以便进一步针对性修复。

## 功能

- **安装第三方手表 App**：在手机选择单个 `.apk` 文件，确认文件名、包名及大小后，通过 ADB `sync:` 协议传输到手表 `/data/local/tmp/`，在手表执行 `pm install -r --user 0`，检查安装结果，最后清理临时 APK。显示传输进度，自动刷新列表。
- **扫描**：读取 Galaxy Watch 8 系统应用和第三方应用列表、包名及停用状态，搜索，支持常见中文名称映射、自定义备注。
- **移除系统预装 App**：确认后 `pm uninstall --user 0 包名`，不擦除只读系统分区，部分组件会拒绝卸载。
- **批量移除、停用/启用**：支持批量勾选，长按列表项可停用、启用、复制包名。
- **恢复记录**：对于系统分区保留的包，尝试 `cmd package install-existing --user 0`；停用的包尝试重新启用。恢复不是绝对保证。
- **风险防护**：保护核心系统组件；不认识的预装应用一律标记为“需谨慎”。误连普通手机只可浏览，不允许修改。
- **自动发现**：尝试发现 ADB 配对或连接的局域网端口；可手动输入更稳定。手机本地保存连接资料和恢复历史，不联网上传数据。

## 使用方法

1. 手机与 Galaxy Watch 8 连接相同 Wi-Fi。手表打开 **设置 → 开发者选项 → 无线调试**。
2. 首次打开“通过配对码配对设备”，将 **手表 IP、配对端口、6 位配对码**填入手机端，点击“进行配对”。
3. 回到手表无线调试首页，读取 **IP:连接端口**（和配对端口不是一个端口），点击“连接手表”。以后通常只需连接，但端口可能变化。
4. **安装**：点击主页绿色的 **“＋ 从手机选择 APK，安装到手表”** → 手机文件管理器选择 `.apk` → 检查包名和提示 → 确认安装。显示传输进度，成功后在“全部 App”列表查看。
5. **删除**：扫描后在“系统预装”列表找到需要处理的应用 → 点击“移除”或勾选批量移除 → 确认。核心应用受到保护。
6. 完成后建议关闭手表的无线调试。

## 安装限制

- 仅单个普通 `.apk`；**不支持 `.apks`、`.apkm`、`.xapk` 或多个拆分 APK 一起安装**。
- 200MB 以内的 APK。读取文件采用 Android 系统文件选择器（SAF），**无需读取整个手机存储的权限**。传输采用 64KB 分块，不将整个文件载入内存。
- APK 必须兼容 Wear OS 的 Android 版本、架构、功能及安装策略。**不是所有手机 APK 都能在手表运行**。签名不匹配、版本或架构不兼容、存储不足和设备限制会使安装失败。
- 从可信来源获取 APK。安装失败时 App 展示手表回传的错误信息。手表临时文件在安装完成或失败后都会尽量清理。
- ADB 首次配对必需，不能一键绕过；连接成功后，安装无需手表端接收程序。

## GitHub 编译（复用原仓库）

原仓库：`https://github.com/weixiaoyinjie/Watch8-System-Cleaner`

1. 上传 `Watch8_System_Manager_V2_2_CryptoFix_OneUpload.zip` **原样到仓库根目录，不解压**，注意与旧版修复 ZIP 不是同一个文件。
2. 进入 `.github/workflows/build-apk.yml`，将文件全文替换为本 ZIP 内同路径 YAML（本次同时提供单独 `Watch8_CryptoFix_V2_2_build-apk.yml` 便于复制）。**这个步骤必须做**，旧 V2 workflow 无法可靠构建新 ZIP。
3. Actions → **Build Watch8 Manager V2.2 CryptoFix APK** → Run workflow。工作流在构建成功后还会自动检查加密类是否确实打包。
4. Artifacts 下载 `Watch8-Manager-V2.2-CryptoFix-Phone-APK`，解压得到手机 APK `app-debug.apk`。

编译工作流会优先强制解压本修复 ZIP，即便仓库已有旧版 `settings.gradle` 和旧源码，也不会悄悄编译旧版。

## 升级 / 数据保留

- 应用包名沿用 `com.watch8.cleaner`（v2.2.0 / versionCode 4），原 V1 记录和 ADB 配对信息可以在**签名一致**的覆盖安装时保留。
- 不同 GitHub Actions 构建可能使用不同的调试签名，如果 Android 提示“签名不一致/无法安装更新”，可能需要先卸载旧版再装新版，这会丢失手机本机的记录和配对密钥，需要重新配对。手表已安装的 App 不受影响。

## 项目文件

- `app/src/main/java/com/watch8/cleaner/MainActivity.java`：安装 APK 选择、确认、进度、原有卸载和恢复界面。
- `app/src/main/java/com/watch8/cleaner/WatchAdb.java`：无线 ADB TLS 连接、sync 文件上传和 shell 操作。
- `app/src/main/java/com/watch8/cleaner/AdbIdentity.java`：保存 RSA 密钥和证书，支持再次连接。
- `app/src/main/java/com/watch8/cleaner/PackageScanner.java`：查询手表 App。
- `app/src/main/java/com/watch8/cleaner/SafetyPolicy.java`：核心组件保护。
- `.github/workflows/build-apk.yml`：支持 ZIP 自动解压、Gradle 构建。

## 配对检查与排障

- 手表在“无线调试 → 使用配对码配对设备”页面，手机填手表的 **IP + 配对端口 + 6 位验证码**，点“进行配对”。不要把手机的无线调试 IP/端口填进去。
- 成功后回到手表“无线调试”主页，在手机 App 填该页面的 **连接端口**，点击“连接手表”。两种端口不要混淆。
- 如果 V2.2.0 App 仍然无法配对，请先重新打开，再点连接面板的“复制诊断”把文本发回。**不要发送完整的 6 位验证码**。
- 若提示加密组件未加载或 native crash，需要手机 Android 版本及诊断文本，才能进一步定位 JNI/ABI 兼容问题。

## 测试说明

这是完整 Android 源码项目，尚未实际在 Galaxy Watch 8 上联机测试；当前环境未安装 Android SDK，**没有声称已经编译成功或已经生成 APK**。已用此项目自带的校验脚本对旧版 APK 执行静态测试：旧 APK 缺失关键加密类（测试未通过，符合预期），新版仍需通过 GitHub Actions 构建校验。应以 GitHub Actions 结果和手表实际安装反馈为准。
